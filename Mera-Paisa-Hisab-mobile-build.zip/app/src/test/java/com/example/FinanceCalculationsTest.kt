package com.example

import com.example.data.ai.SmartEntryParser
import com.example.util.IndianFormatters
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FinanceCalculationsTest {

    @Test
    fun indianCurrencyFormatting_usesLakhsCroresGrouping() {
        assertEquals("₹100", IndianFormatters.formatInr(10000L))
        assertEquals("₹1,250.50", IndianFormatters.formatInr(125050L))
        assertEquals("₹1,25,000", IndianFormatters.formatInr(12500000L))
        assertEquals("-₹500", IndianFormatters.formatInr(-50000L))
        assertEquals("+₹2,500", IndianFormatters.formatInr(250000L, showPlus = true))
    }

    @Test
    fun indianDateFormatting_usesDdMmYyyy() {
        assertEquals("17-11-2026", IndianFormatters.formatIndianDate("2026-11-17"))
        assertEquals("05-01-2026", IndianFormatters.formatIndianDate("2026-01-05"))
        assertEquals("नवंबर 2026", IndianFormatters.formatIndianMonthTitle("2026-11"))
    }

    @Test
    fun rupeeParsing_convertsToExactPaise() {
        assertEquals(10000L, IndianFormatters.parseRupeesToPaise("100"))
        assertEquals(12550L, IndianFormatters.parseRupeesToPaise("125.5"))
        assertEquals(10000000L, IndianFormatters.parseRupeesToPaise("1,00,000"))
        assertEquals(null, IndianFormatters.parseRupeesToPaise("-50"))
    }

    @Test
    fun offlineSmartParser_handlesHindiAndHinglishInputs() {
        val parser = SmartEntryParser()

        val vagueExpense = parser.parseOffline("Aaj 100 rupaye kharch hue")
        assertEquals("EXPENSE", vagueExpense.intentKind)
        assertEquals(10000L, vagueExpense.amountPaise)
        assertEquals(IndianFormatters.todayDateKey(), vagueExpense.dateKey)
        assertTrue(vagueExpense.needsConfirmation)

        val clearExpense = parser.parseOffline("Kal 250 rupaye sabzi kharida")
        assertEquals("EXPENSE", clearExpense.intentKind)
        assertEquals(25000L, clearExpense.amountPaise)
        assertEquals(IndianFormatters.yesterdayDateKey(), clearExpense.dateKey)
        assertEquals("राशन", clearExpense.category)
        assertFalse(clearExpense.needsConfirmation)

        val income = parser.parseOffline("Aaj 15000 salary aayi")
        assertEquals("INCOME", income.intentKind)
        assertEquals(1500000L, income.amountPaise)
        assertEquals("वेतन", income.category)

        val udhar = parser.parseOffline("Ramesh ko 500 udhar diye")
        assertEquals("UDHAR_GIVEN", udhar.intentKind)
        assertEquals(50000L, udhar.amountPaise)
        assertEquals("Ramesh", udhar.personName)
    }
}
