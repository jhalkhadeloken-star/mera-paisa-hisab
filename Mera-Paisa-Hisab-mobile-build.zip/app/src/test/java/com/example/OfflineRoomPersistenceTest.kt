package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.model.EntrySource
import com.example.data.model.TransactionType
import com.example.data.model.UdharEntryType
import com.example.data.repository.FinanceRepository
import com.example.util.ReportExporter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class OfflineRoomPersistenceTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var repository: FinanceRepository

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = FinanceRepository(db.financeDao())
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun offlineRepository_savesProfileTransactionsUdharAndJsonBackup() = runTest {
        assertTrue(repository.ensureUserProfile().isSuccess)
        val defaultProfile = repository.observeProfile().first()
        assertNotNull(defaultProfile)
        assertEquals("मेरा खाता", defaultProfile?.displayName)

        assertTrue(
            repository.updateProfileSettings(
                displayName = "राजेश शर्मा",
                openingBalancePaise = 500_00L,
                monthlyBudgetPaise = 10_000_00L
            ).isSuccess
        )

        assertTrue(
            repository.saveTransaction(
                transactionId = "tx-1",
                isEdit = false,
                type = TransactionType.EXPENSE,
                amountPaise = 120_00L,
                category = "खाना-पीना",
                note = "सुबह का नाश्ता",
                dateKey = "2026-11-17",
                source = EntrySource.MANUAL
            ).isSuccess
        )

        assertTrue(
            repository.saveUdharEntry(
                entryId = "udhar-1",
                isEdit = false,
                personName = "अमित",
                phone = "9876543210",
                entryType = UdharEntryType.GIVEN,
                amountPaise = 500_00L,
                dateKey = "2026-11-17",
                dueDateKey = null,
                note = "दवाई के लिए"
            ).isSuccess
        )

        val profile = repository.observeProfile().first()
        val txs = repository.observeTransactions().first()
        val udhars = repository.observeUdharEntries().first()

        assertEquals("राजेश शर्मा", profile?.displayName)
        assertEquals(500_00L, profile?.openingBalancePaise)
        assertEquals(1, txs.size)
        assertEquals(120_00L, txs.first().amountPaise)
        assertEquals(1, udhars.size)
        assertEquals("अमित", udhars.first().personName)

        val backupResult = ReportExporter.exportJsonBackup(context, profile, txs, udhars)
        assertTrue(backupResult.isSuccess)
        val backupFile = File(context.cacheDir, "exports/MeraPaisaHisab_Backup.json")
        assertTrue(backupFile.exists())
        val json = JSONObject(backupFile.readText(Charsets.UTF_8))
        assertEquals("Mera Paisa Hisab", json.getString("app"))
        assertEquals(1, json.getJSONArray("transactions").length())
        assertEquals(1, json.getJSONArray("udharEntries").length())

        assertTrue(repository.deleteTransaction("tx-1").isSuccess)
        assertEquals(0, repository.observeTransactions().first().size)
    }

    @Test
    fun installedApkInfo_reportsMetadataSafely() {
        val info = ReportExporter.getInstalledApkInfo(context)
        assertEquals("MeraPaisaHisab-v${info.versionName}.apk", info.suggestedFileName)
    }
}
