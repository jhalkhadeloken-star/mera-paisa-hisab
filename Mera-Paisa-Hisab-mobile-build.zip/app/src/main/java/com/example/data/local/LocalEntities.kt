package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: Int = 1,
    val displayName: String = "मेरा खाता",
    val openingBalancePaise: Long = 0L,
    val monthlyBudgetPaise: Long = 0L,
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String,
    val type: String,
    val amountPaise: Long,
    val category: String,
    val note: String,
    val dateKey: String,
    val monthKey: String,
    val source: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)

@Entity(tableName = "udhar_entries")
data class UdharEntryEntity(
    @PrimaryKey val id: String,
    val personName: String,
    val personKey: String,
    val phone: String?,
    val entryType: String,
    val amountPaise: Long,
    val dateKey: String,
    val dueDateKey: String?,
    val note: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)
