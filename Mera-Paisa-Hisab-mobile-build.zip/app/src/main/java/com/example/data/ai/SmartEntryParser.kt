package com.example.data.ai

import android.util.Log
import com.example.data.model.FinanceCategories
import com.example.data.model.TransactionType
import com.example.util.IndianFormatters
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.util.Locale

data class SmartParseResult(
    val intentKind: String, // "EXPENSE" | "INCOME" | "UDHAR_GIVEN" | "UDHAR_BORROWED" | "UDHAR_REPAYMENT_RECEIVED" | "UDHAR_REPAYMENT_PAID"
    val amountPaise: Long?,
    val dateKey: String,
    val category: String,
    val note: String,
    val personName: String,
    val needsConfirmation: Boolean,
    val clarificationQuestion: String,
    val usedAi: Boolean
)

class SmartEntryParser {

    private val schema = Schema.obj(
        properties = mapOf(
            "intentKind" to Schema.enumeration(
                values = listOf(
                    "EXPENSE",
                    "INCOME",
                    "UDHAR_GIVEN",
                    "UDHAR_BORROWED",
                    "UDHAR_REPAYMENT_RECEIVED",
                    "UDHAR_REPAYMENT_PAID"
                ),
                description = "Whether this is an expense, income, or udhar (loan/repayment) entry."
            ),
            "amountRupees" to Schema.double(
                description = "Numeric amount in Indian Rupees, or 0 if not mentioned or unclear.",
                nullable = true
            ),
            "dateKey" to Schema.string(
                description = "Date in YYYY-MM-DD format relative to today's date provided in prompt."
            ),
            "category" to Schema.string(
                description = "Best matching Hindi category: for EXPENSE choose one of [भोजन, राशन, यात्रा, किराया, बिल, स्वास्थ्य, खरीदारी, शिक्षा, मनोरंजन, अन्य]; for INCOME choose one of [वेतन, व्यापार, बोनस, ब्याज, अन्य आय]; for UDHAR use उधार."
            ),
            "note" to Schema.string(
                description = "Short clean Hindi description of the transaction (max 80 chars)."
            ),
            "personName" to Schema.string(
                description = "Person name if this is an udhar entry, otherwise empty string."
            ),
            "needsConfirmation" to Schema.boolean(
                description = "True if amount is missing/zero, type is ambiguous, or description/category is vague (e.g. 'Aaj 100 rupaye kharch hue' without item details)."
            ),
            "clarificationQuestion" to Schema.string(
                description = "Friendly short Hindi question asking user to confirm or fill unclear info, or empty string if everything is clear."
            )
        )
    )

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = schema
            }
        )
    }

    suspend fun parseSmartInput(
        userInput: String,
        isOnline: Boolean
    ): Result<SmartParseResult> {
        val trimmed = userInput.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(IllegalArgumentException("कृपया खर्च या आय का विवरण लिखें।"))
        }

        if (!isOnline) {
            return Result.success(parseOffline(trimmed))
        }

        val today = IndianFormatters.todayDateKey()
        val yesterday = IndianFormatters.yesterdayDateKey()
        val dayBefore = IndianFormatters.daysAgoDateKey(2)

        val prompt = """
            You are an Indian personal finance assistant for the Hindi app "Mera Paisa Hisab".
            Today's date is $today (yesterday was $yesterday, day before yesterday was $dayBefore).
            Parse the user's Hindi, Devanagari, or Hinglish sentence into structured JSON.

            Rules:
            - Understand phrases like "Aaj 100 rupaye kharch hue", "Kal 250 sabzi par kharch", "500 salary mili", "Ramesh ko 1000 udhar diye", "Suresh ne 500 wapas kiye", "100rs chai".
            - If the user writes a generic expense like "Aaj 100 rupaye kharch hue" without saying WHAT they spent on, set category="अन्य", note="दैनिक खर्च", needsConfirmation=true, and clarificationQuestion="यह ₹100 किस चीज़ पर खर्च हुए? कृपया श्रेणी चुनें या विवरण जोड़ें।".
            - If amount is missing or <= 0, set needsConfirmation=true and ask for the amount in Hindi.
            - Always output Hindi labels for category, note, and clarificationQuestion.

            User input: "$trimmed"
        """.trimIndent()

        return try {
            val response = withTimeout(30_000L) {
                model.generateContent(prompt)
            }
            val jsonText = response.text
            if (jsonText.isNullOrBlank()) {
                return Result.failure(IllegalStateException("AI से खाली उत्तर प्राप्त हुआ।"))
            }
            val json = JSONObject(jsonText)
            val intentKind = json.optString("intentKind", "EXPENSE")
            val amountRupees = if (json.isNull("amountRupees")) null else json.optDouble("amountRupees", 0.0)
            val amountPaise = if (amountRupees != null && amountRupees > 0.0) {
                kotlin.math.round(amountRupees * 100.0).toLong()
            } else {
                null
            }
            val rawDateKey = json.optString("dateKey", today)
            val dateKey = if (Regex("^\\d{4}-\\d{2}-\\d{2}$").matches(rawDateKey)) rawDateKey else today
            val category = sanitizeCategory(json.optString("category", "अन्य"), intentKind)
            val note = json.optString("note", "").trim().take(200)
            val personName = json.optString("personName", "").trim().take(80)
            val needsConfirmation = json.optBoolean("needsConfirmation", amountPaise == null) || amountPaise == null
            val clarificationQuestion = json.optString("clarificationQuestion", "").trim()

            Result.success(
                SmartParseResult(
                    intentKind = intentKind,
                    amountPaise = amountPaise,
                    dateKey = dateKey,
                    category = category,
                    note = note.ifBlank { trimmed.take(80) },
                    personName = personName,
                    needsConfirmation = needsConfirmation,
                    clarificationQuestion = if (needsConfirmation && clarificationQuestion.isBlank()) {
                        "कृपया राशि, श्रेणी और विवरण की पुष्टि करें।"
                    } else {
                        clarificationQuestion
                    },
                    usedAi = true
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Firebase AI smart entry timed out", e)
            Result.failure(e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Firebase AI smart entry failed", e)
            Result.failure(e)
        }
    }

    fun parseOffline(userInput: String): SmartParseResult {
        val text = userInput.trim()
        val lower = text.lowercase(Locale.getDefault())

        // 1. Extract Date
        val dateKey = when {
            lower.contains("parso") || lower.contains("परसों") -> IndianFormatters.daysAgoDateKey(2)
            lower.contains("kal") || lower.contains("कल") || lower.contains("yesterday") -> IndianFormatters.yesterdayDateKey()
            else -> IndianFormatters.todayDateKey()
        }

        // 2. Extract Amount
        val amountRegex = Regex("(?:₹|rs\\.?|inr)?\\s*(\\d+(?:\\.\\d{1,2})?)\\s*(?:₹|rs\\.?|rupaye|rupee|rupees|रुपये|रुपए|रु)?")
        val numberMatch = Regex("\\d+(?:\\.\\d{1,2})?").find(lower)
        val parsedAmountRupees = numberMatch?.value?.toDoubleOrNull()
        val amountPaise = if (parsedAmountRupees != null && parsedAmountRupees > 0.0) {
            kotlin.math.round(parsedAmountRupees * 100.0).toLong()
        } else {
            amountRegex.find(lower)?.groupValues?.getOrNull(1)?.toDoubleOrNull()?.let {
                if (it > 0.0) kotlin.math.round(it * 100.0).toLong() else null
            }
        }

        // 3. Detect Udhar vs Income vs Expense
        val isUdharKeyword = listOf("udhar", "उधार", "karz", "कर्ज", "baaki", "बाकी", "wapas", "वापस", "liya", "liye", "diya", "diye").any { lower.contains(it) }
        val isIncomeKeyword = listOf(
            "salary", "सैलरी", "vetan", "वेतन", "income", "आय", "kamai", "कमाई",
            "bonus", "बोनस", "byaj", "ब्याज", "profit", "मुनाफा", "aayi", "aaye", "aaya", "मिली", "मिले", "आए", "आया"
        ).any { lower.contains(it) }
        val isExpenseKeyword = listOf(
            "kharch", "खर्च", "spent", "buy", "bought", "kharida", "खरीदा", "kharcha", "खर्चा", "bill", "बिल", "paid", "दिए"
        ).any { lower.contains(it) }

        val intentKind = when {
            lower.contains("udhar") || lower.contains("उधार") -> {
                when {
                    lower.contains("wapas") || lower.contains("वापस") -> {
                        if (lower.contains("mila") || lower.contains("mile") || lower.contains("मिला") || lower.contains("मिले") || lower.contains("ne ")) {
                            "UDHAR_REPAYMENT_RECEIVED"
                        } else {
                            "UDHAR_REPAYMENT_PAID"
                        }
                    }
                    lower.contains("liya") || lower.contains("liye") || lower.contains("लिया") || lower.contains("लिए") || lower.contains("se ") -> "UDHAR_BORROWED"
                    else -> "UDHAR_GIVEN"
                }
            }
            isUdharKeyword && (lower.contains("wapas") || lower.contains("वापस")) -> {
                if (lower.contains("mila") || lower.contains("mile") || lower.contains("मिला")) "UDHAR_REPAYMENT_RECEIVED"
                else "UDHAR_REPAYMENT_PAID"
            }
            isIncomeKeyword && !isExpenseKeyword -> "INCOME"
            else -> "EXPENSE"
        }

        // Extract person name for udhar
        var personName = ""
        if (intentKind.startsWith("UDHAR")) {
            val personRegex = Regex("^([A-Za-z\\u0900-\\u097F]+)\\s+(?:ko|ne|se|को|ने|से)\\b", RegexOption.IGNORE_CASE)
            personName = personRegex.find(text)?.groupValues?.getOrNull(1)?.trim().orEmpty()
        }

        // 4. Category detection
        val (category, matchedSpecificCategory) = detectCategoryOffline(lower, intentKind)

        // 5. Determine if confirmation/clarification is required
        val reasons = mutableListOf<String>()
        if (amountPaise == null) {
            reasons.add("राशि स्पष्ट नहीं है")
        }
        if (intentKind.startsWith("UDHAR") && personName.isBlank()) {
            reasons.add("व्यक्ति का नाम स्पष्ट नहीं है")
        }
        if (intentKind == "EXPENSE" && !matchedSpecificCategory) {
            reasons.add("खर्च की श्रेणी व विवरण स्पष्ट नहीं है")
        }
        if (!isIncomeKeyword && !isExpenseKeyword && !intentKind.startsWith("UDHAR")) {
            reasons.add("यह खर्च है या आय, यह स्पष्ट नहीं है")
        }

        val needsConfirmation = reasons.isNotEmpty()
        val clarificationQuestion = when {
            amountPaise == null -> "कृपया सही राशि (₹) दर्ज करें और विवरण जांचें।"
            intentKind.startsWith("UDHAR") && personName.isBlank() -> "कृपया व्यक्ति का नाम और उधार प्रकार की पुष्टि करें।"
            reasons.isNotEmpty() -> "जानकारी अधूरी है (${reasons.joinToString(", ")})। कृपया पुष्टि करें।"
            else -> ""
        }

        val cleanNote = text
            .replace(Regex("\\b(aaj|kal|parso|rupaye|rupees|rupee|rs\\.?|kharch|hue|hui|hua|आज|कल|परसों|रुपये|रुपए|खर्च|हुए|हुई|हुआ)\\b", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\s+"), " ")
            .trim()
            .ifBlank {
                if (intentKind == "INCOME") "दैनिक आय" else if (intentKind.startsWith("UDHAR")) "उधार लेन-देन" else "दैनिक खर्च"
            }

        return SmartParseResult(
            intentKind = intentKind,
            amountPaise = amountPaise,
            dateKey = dateKey,
            category = category,
            note = cleanNote.take(120),
            personName = personName,
            needsConfirmation = needsConfirmation,
            clarificationQuestion = clarificationQuestion,
            usedAi = false
        )
    }

    private fun detectCategoryOffline(lower: String, intentKind: String): Pair<String, Boolean> {
        if (intentKind.startsWith("UDHAR")) return "उधार" to true
        if (intentKind == "INCOME") {
            return when {
                listOf("salary", "vetan", "सैलरी", "वेतन", "तनख्वाह").any { lower.contains(it) } -> "वेतन" to true
                listOf("business", "vyapar", "dukan", "दुकान", "व्यापार", "बिक्री", "profit").any { lower.contains(it) } -> "व्यापार" to true
                listOf("bonus", "बोनस", "gift", "उपहार", "इनाम").any { lower.contains(it) } -> "बोनस" to true
                listOf("interest", "byaj", "ब्याज").any { lower.contains(it) } -> "ब्याज" to true
                else -> "अन्य आय" to false
            }
        }
        return when {
            listOf("khana", "chai", "coffee", "nashta", "lunch", "dinner", "breakfast", "hotel", "restaurant", "samosa", "खाना", "चाय", "नाश्ता", "भोजन", "मिठाई").any { lower.contains(it) } -> "भोजन" to true
            listOf("sabzi", "doodh", "rashan", "ration", "atta", "chawal", "kirana", "grocery", "fruit", "सब्जी", "सब्ज़ी", "दूध", "राशन", "किराना", "फल").any { lower.contains(it) } -> "राशन" to true
            listOf("petrol", "diesel", "auto", "bus", "train", "metro", "cab", "uber", "ola", "ticket", "travel", "petrol", "पेट्रोल", "ऑटो", "बस", "ट्रेन", "यात्रा", "किराया सफर").any { lower.contains(it) } -> "यात्रा" to true
            listOf("rent", "kiraya", "room", "कमरा", "किराया", "मकान").any { lower.contains(it) } -> "किराया" to true
            listOf("bill", "bijli", "electricity", "recharge", "wifi", "internet", "gas", "cylinder", "पानी", "बिजली", "रिचार्ज", "बिल", "गैस").any { lower.contains(it) } -> "बिल" to true
            listOf("dawai", "medicine", "doctor", "hospital", "clinic", "test", "दवाई", "दवा", "डॉक्टर", "अस्पताल", "स्वास्थ्य").any { lower.contains(it) } -> "स्वास्थ्य" to true
            listOf("kapde", "clothes", "shoes", "shopping", "amazon", "flipkart", "जूते", "कपड़े", "खरीदारी", "शॉपिंग").any { lower.contains(it) } -> "खरीदारी" to true
            listOf("school", "fees", "book", "copy", "pen", "tuition", "college", "स्कूल", "फीस", "किताब", "शिक्षा", "कॉपी").any { lower.contains(it) } -> "शिक्षा" to true
            listOf("movie", "cinema", "game", "party", "फिल्म", "सिनेमा", "पार्टी", "मनोरंजन").any { lower.contains(it) } -> "मनोरंजन" to true
            else -> "अन्य" to false
        }
    }

    private fun sanitizeCategory(raw: String, intentKind: String): String {
        val cleaned = raw.trim()
        if (intentKind.startsWith("UDHAR")) return "उधार"
        val valid = if (intentKind == "INCOME") {
            FinanceCategories.incomeCategories.map { it.name }
        } else {
            FinanceCategories.expenseCategories.map { it.name }
        }
        return valid.firstOrNull { it == cleaned }
            ?: if (intentKind == "INCOME") "अन्य आय" else "अन्य"
    }

    private companion object {
        const val TAG = "SmartEntryParser"
    }
}
