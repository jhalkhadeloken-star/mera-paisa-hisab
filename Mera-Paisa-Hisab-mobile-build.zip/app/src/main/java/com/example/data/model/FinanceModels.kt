package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.AccountTree
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.HealthAndSafety
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LocalGroceryStore
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Restaurant
import androidx.compose.material.icons.rounded.Savings
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.Work
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ui.theme.ChartColors

data class UserProfile(
    val id: String = "local_user",
    val displayName: String = "मेरा खाता",
    val openingBalancePaise: Long = 0L,
    val monthlyBudgetPaise: Long = 0L,
    val updatedAtMillis: Long = 0L
)

data class LedgerTransaction(
    val id: String = "",
    val type: String = TransactionType.EXPENSE.name,
    val amountPaise: Long = 0L,
    val category: String = "अन्य",
    val note: String = "",
    val dateKey: String = "",
    val monthKey: String = "",
    val source: String = EntrySource.MANUAL.name,
    val createdAtMillis: Long = 0L,
    val updatedAtMillis: Long = 0L
) {
    fun transactionType(): TransactionType =
        enumValues<TransactionType>().firstOrNull { it.name == type } ?: TransactionType.EXPENSE
}

data class UdharEntry(
    val id: String = "",
    val personName: String = "",
    val personKey: String = "",
    val phone: String? = null,
    val entryType: String = UdharEntryType.GIVEN.name,
    val amountPaise: Long = 0L,
    val dateKey: String = "",
    val dueDateKey: String? = null,
    val note: String = "",
    val createdAtMillis: Long = 0L,
    val updatedAtMillis: Long = 0L
) {
    fun udharType(): UdharEntryType =
        enumValues<UdharEntryType>().firstOrNull { it.name == entryType } ?: UdharEntryType.GIVEN
}

enum class TransactionType(val hindiLabel: String) {
    EXPENSE("खर्च"),
    INCOME("आय")
}

enum class UdharEntryType(val hindiLabel: String, val shortHint: String) {
    GIVEN("उधार दिया", "मैंने पैसे दिए (लेना है)"),
    BORROWED("उधार लिया", "मैंने पैसे लिए (देना है)"),
    REPAYMENT_RECEIVED("वापस मिला", "दिया हुआ पैसा वापस मिला"),
    REPAYMENT_PAID("वापस किया", "लिया हुआ उधार चुकाया")
}

enum class EntrySource {
    MANUAL,
    SMART_TEXT,
    UDHAR_SYNC
}

data class CategoryInfo(
    val name: String,
    val icon: ImageVector,
    val color: Color
)

object FinanceCategories {
    val expenseCategories = listOf(
        CategoryInfo("भोजन", Icons.Rounded.Restaurant, ChartColors[0]),
        CategoryInfo("राशन", Icons.Rounded.LocalGroceryStore, ChartColors[1]),
        CategoryInfo("यात्रा", Icons.Rounded.DirectionsCar, ChartColors[2]),
        CategoryInfo("किराया", Icons.Rounded.Home, ChartColors[3]),
        CategoryInfo("बिल", Icons.Rounded.ReceiptLong, ChartColors[4]),
        CategoryInfo("स्वास्थ्य", Icons.Rounded.HealthAndSafety, ChartColors[5]),
        CategoryInfo("खरीदारी", Icons.Rounded.ShoppingBag, ChartColors[6]),
        CategoryInfo("शिक्षा", Icons.Rounded.School, ChartColors[7]),
        CategoryInfo("मनोरंजन", Icons.Rounded.Movie, ChartColors[8]),
        CategoryInfo("अन्य", Icons.Rounded.MoreHoriz, ChartColors[9])
    )

    val incomeCategories = listOf(
        CategoryInfo("वेतन", Icons.Rounded.Work, Color(0xFF15803D)),
        CategoryInfo("व्यापार", Icons.Rounded.AccountTree, Color(0xFF0D9488)),
        CategoryInfo("बोनस", Icons.Rounded.CardGiftcard, Color(0xFF2563EB)),
        CategoryInfo("ब्याज", Icons.Rounded.Savings, Color(0xFFD97706)),
        CategoryInfo("अन्य आय", Icons.Rounded.AccountBalanceWallet, Color(0xFF64748B))
    )

    fun infoFor(category: String, type: TransactionType): CategoryInfo {
        val list = if (type == TransactionType.INCOME) incomeCategories else expenseCategories
        return list.firstOrNull { it.name == category }
            ?: CategoryInfo(
                name = category.ifBlank { "अन्य" },
                icon = if (type == TransactionType.INCOME) Icons.Rounded.AccountBalanceWallet else Icons.Rounded.MoreHoriz,
                color = if (type == TransactionType.INCOME) Color(0xFF15803D) else ChartColors[9]
            )
    }
}

data class PersonUdharSummary(
    val personKey: String,
    val personName: String,
    val phone: String?,
    val totalGivenPaise: Long,
    val totalBorrowedPaise: Long,
    val totalRepaidToMePaise: Long,
    val totalRepaidByMePaise: Long,
    val netBalancePaise: Long,
    val latestDateKey: String,
    val entries: List<UdharEntry>
)

data class DashboardSummary(
    val todayExpensePaise: Long = 0L,
    val todayIncomePaise: Long = 0L,
    val todaySavingsPaise: Long = 0L,
    val monthExpensePaise: Long = 0L,
    val monthIncomePaise: Long = 0L,
    val monthSavingsPaise: Long = 0L,
    val totalUdharReceivablePaise: Long = 0L,
    val totalUdharPayablePaise: Long = 0L,
    val netPendingUdharPaise: Long = 0L,
    val availableBalancePaise: Long = 0L,
    val openingBalancePaise: Long = 0L,
    val monthlyBudgetPaise: Long = 0L
)

data class DailyBarPoint(
    val dateKey: String,
    val shortLabel: String,
    val incomePaise: Long,
    val expensePaise: Long
)

data class CategoryBreakdown(
    val category: String,
    val amountPaise: Long,
    val percentage: Float,
    val color: Color
)

data class MonthlySummaryRow(
    val monthKey: String,
    val monthTitle: String,
    val incomePaise: Long,
    val expensePaise: Long,
    val savingsPaise: Long,
    val transactionCount: Int
)

data class MonthlyReportData(
    val selectedMonthKey: String,
    val selectedMonthTitle: String,
    val monthIncomePaise: Long,
    val monthExpensePaise: Long,
    val monthSavingsPaise: Long,
    val savingsRatePercent: Int,
    val categoryBreakdowns: List<CategoryBreakdown>,
    val monthTransactions: List<LedgerTransaction>,
    val previousMonths: List<MonthlySummaryRow>,
    val availableMonthKeys: List<String>
)
