package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.local.FinanceDao
import com.example.data.local.TransactionEntity
import com.example.data.local.UdharEntryEntity
import com.example.data.local.UserProfileEntity
import com.example.data.model.EntrySource
import com.example.data.model.LedgerTransaction
import com.example.data.model.TransactionType
import com.example.data.model.UdharEntry
import com.example.data.model.UdharEntryType
import com.example.data.model.UserProfile
import com.example.util.IndianFormatters
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Locale
import java.util.UUID

class FinanceRepository(private val dao: FinanceDao) {

    constructor(context: Context) : this(
        AppDatabase.getInstance(context.applicationContext).financeDao()
    )

    fun observeProfile(): Flow<UserProfile?> =
        dao.observeProfile().map { entity ->
            entity?.let {
                UserProfile(
                    id = "local_user",
                    displayName = it.displayName,
                    openingBalancePaise = it.openingBalancePaise,
                    monthlyBudgetPaise = it.monthlyBudgetPaise,
                    updatedAtMillis = it.updatedAtMillis
                )
            }
        }

    fun observeTransactions(): Flow<List<LedgerTransaction>> =
        dao.observeTransactions().map { list ->
            list.map { entity ->
                LedgerTransaction(
                    id = entity.id,
                    type = entity.type,
                    amountPaise = entity.amountPaise,
                    category = entity.category,
                    note = entity.note,
                    dateKey = entity.dateKey,
                    monthKey = entity.monthKey,
                    source = entity.source,
                    createdAtMillis = entity.createdAtMillis,
                    updatedAtMillis = entity.updatedAtMillis
                )
            }
        }

    fun observeUdharEntries(): Flow<List<UdharEntry>> =
        dao.observeUdharEntries().map { list ->
            list.map { entity ->
                UdharEntry(
                    id = entity.id,
                    personName = entity.personName,
                    personKey = entity.personKey,
                    phone = entity.phone,
                    entryType = entity.entryType,
                    amountPaise = entity.amountPaise,
                    dateKey = entity.dateKey,
                    dueDateKey = entity.dueDateKey,
                    note = entity.note,
                    createdAtMillis = entity.createdAtMillis,
                    updatedAtMillis = entity.updatedAtMillis
                )
            }
        }

    suspend fun ensureUserProfile(): Result<Unit> {
        return try {
            val existing = dao.getProfileOnce()
            if (existing == null) {
                dao.upsertProfile(
                    UserProfileEntity(
                        id = 1,
                        displayName = "मेरा खाता",
                        openingBalancePaise = 0L,
                        monthlyBudgetPaise = 0L,
                        updatedAtMillis = System.currentTimeMillis()
                    )
                )
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateProfileSettings(
        displayName: String,
        openingBalancePaise: Long,
        monthlyBudgetPaise: Long
    ): Result<Unit> {
        return try {
            require(openingBalancePaise in 0L..100_000_000_000L) {
                "शुरुआती बैलेंस मान्य सीमा के भीतर होना चाहिए।"
            }
            require(monthlyBudgetPaise in 0L..100_000_000_000L) {
                "मासिक बजट मान्य सीमा के भीतर होना चाहिए।"
            }
            val safeName = displayName.trim().ifBlank { "मेरा खाता" }.take(100)
            dao.upsertProfile(
                UserProfileEntity(
                    id = 1,
                    displayName = safeName,
                    openingBalancePaise = openingBalancePaise,
                    monthlyBudgetPaise = monthlyBudgetPaise,
                    updatedAtMillis = System.currentTimeMillis()
                )
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveTransaction(
        transactionId: String?,
        isEdit: Boolean,
        type: TransactionType,
        amountPaise: Long,
        category: String,
        note: String,
        dateKey: String,
        source: EntrySource
    ): Result<Unit> {
        return try {
            val docId = transactionId?.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
            require(amountPaise in 1L..100_000_000_000L) {
                "राशि ₹0 से अधिक होनी चाहिए।"
            }
            val safeCategory = category.trim().ifBlank { "अन्य" }.take(60)
            val safeNote = note.trim().take(250)
            require(Regex("^\\d{4}-\\d{2}-\\d{2}$").matches(dateKey)) {
                "तारीख प्रारूप अमान्य है।"
            }
            val monthKey = IndianFormatters.dateKeyToMonthKey(dateKey)
            val now = System.currentTimeMillis()
            val existingCreatedAt = if (isEdit) {
                dao.getTransactionById(docId)?.createdAtMillis ?: now
            } else {
                now
            }

            dao.upsertTransaction(
                TransactionEntity(
                    id = docId,
                    type = type.name,
                    amountPaise = amountPaise,
                    category = safeCategory,
                    note = safeNote,
                    dateKey = dateKey,
                    monthKey = monthKey,
                    source = source.name,
                    createdAtMillis = existingCreatedAt,
                    updatedAtMillis = now
                )
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteTransaction(transactionId: String): Result<Unit> {
        return try {
            require(transactionId.isNotBlank()) { "Transaction ID cannot be blank" }
            dao.deleteTransactionById(transactionId)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveUdharEntry(
        entryId: String?,
        isEdit: Boolean,
        personName: String,
        phone: String?,
        entryType: UdharEntryType,
        amountPaise: Long,
        dateKey: String,
        dueDateKey: String?,
        note: String
    ): Result<Unit> {
        return try {
            val docId = entryId?.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
            val safeName = personName.trim().take(80)
            require(safeName.isNotEmpty()) { "कृपया व्यक्ति का नाम दर्ज करें।" }
            val personKey = safeName.lowercase(Locale.getDefault()).replace(Regex("\\s+"), " ")
            require(amountPaise in 1L..100_000_000_000L) {
                "राशि ₹0 से अधिक होनी चाहिए।"
            }
            require(Regex("^\\d{4}-\\d{2}-\\d{2}$").matches(dateKey)) {
                "तारीख प्रारूप अमान्य है।"
            }
            val cleanPhone = phone?.trim()?.takeIf { it.isNotEmpty() }?.take(20)
            val cleanDueDate = dueDateKey?.trim()?.takeIf { Regex("^\\d{4}-\\d{2}-\\d{2}$").matches(it) }
            val safeNote = note.trim().take(250)
            val now = System.currentTimeMillis()
            val existingCreatedAt = if (isEdit) {
                dao.getUdharEntryById(docId)?.createdAtMillis ?: now
            } else {
                now
            }

            dao.upsertUdharEntry(
                UdharEntryEntity(
                    id = docId,
                    personName = safeName,
                    personKey = personKey,
                    phone = cleanPhone,
                    entryType = entryType.name,
                    amountPaise = amountPaise,
                    dateKey = dateKey,
                    dueDateKey = cleanDueDate,
                    note = safeNote,
                    createdAtMillis = existingCreatedAt,
                    updatedAtMillis = now
                )
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteUdharEntry(entryId: String): Result<Unit> {
        return try {
            require(entryId.isNotBlank()) { "Entry ID cannot be blank" }
            dao.deleteUdharEntryById(entryId)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
