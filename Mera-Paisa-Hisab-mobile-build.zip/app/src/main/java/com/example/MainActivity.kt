package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Handshake
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Handshake
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.ai.SmartEntryParser
import com.example.data.model.EntrySource
import com.example.data.model.LedgerTransaction
import com.example.data.model.TransactionType
import com.example.data.model.UdharEntryType
import com.example.data.repository.FinanceRepository
import com.example.firebase.configureAppCheck
import com.example.ui.components.AddEditTransactionSheet
import com.example.ui.components.ApkDownloadBottomSheet
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.SettingsBottomSheet
import com.example.ui.components.SmartParseConfirmationSheet
import com.example.ui.screens.AddEditUdharSheet
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.ReportScreen
import com.example.ui.screens.UdharScreen
import com.example.ui.theme.MeraPaisaHisabTheme
import com.example.ui.viewmodel.FinanceViewModel
import com.example.ui.viewmodel.SmartParseUiState
import com.example.ui.viewmodel.UiState
import com.example.util.IndianFormatters
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // App Check allows optional online AI smart text parsing without requiring Gmail login
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            MeraPaisaHisabTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    OfflineAppShell()
                }
            }
        }
    }
}

private enum class AppTab(
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    DASHBOARD("डैशबोर्ड", Icons.Rounded.Dashboard, Icons.Outlined.Dashboard, "nav_dashboard"),
    HISTORY("इतिहास", Icons.Rounded.ReceiptLong, Icons.Outlined.ReceiptLong, "nav_history"),
    UDHAR("उधार", Icons.Rounded.Handshake, Icons.Outlined.Handshake, "nav_udhar"),
    REPORTS("रिपोर्ट", Icons.Rounded.Assessment, Icons.Outlined.Assessment, "nav_reports")
}

@Composable
fun OfflineAppShell() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val viewModel: FinanceViewModel = viewModel(
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                FinanceViewModel(
                    repository = FinanceRepository(app),
                    smartParser = SmartEntryParser()
                )
            }
        }
    )

    val uiState by viewModel.mainState.collectAsStateWithLifecycle()
    val smartParseState by viewModel.smartParseState.collectAsStateWithLifecycle()
    val isSaving by viewModel.isSaving.collectAsStateWithLifecycle()
    val isOnline by remember(context) {
        IndianFormatters.observeNetworkConnectivity(context)
    }.collectAsStateWithLifecycle(initialValue = IndianFormatters.isNetworkAvailable(context))

    LaunchedEffect(viewModel) {
        viewModel.events.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    var currentTab by remember { mutableStateOf(AppTab.DASHBOARD) }
    var showAddEditTxSheet by remember { mutableStateOf(false) }
    var editingTx by remember { mutableStateOf<LedgerTransaction?>(null) }
    var defaultTxType by remember { mutableStateOf(TransactionType.EXPENSE) }
    var deletingTx by remember { mutableStateOf<LedgerTransaction?>(null) }

    var showQuickUdharSheet by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var showApkSheet by remember { mutableStateOf(false) }

    if (currentTab != AppTab.DASHBOARD) {
        BackHandler {
            currentTab = AppTab.DASHBOARD
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(windowInsets = WindowInsets.navigationBars) {
                        AppTab.entries.forEach { tab ->
                            val selected = currentTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { currentTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label, maxLines = 1) },
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }
            },
            floatingActionButton = {
                if (currentTab == AppTab.DASHBOARD || currentTab == AppTab.HISTORY) {
                    FloatingActionButton(
                        onClick = {
                            editingTx = null
                            defaultTxType = TransactionType.EXPENSE
                            showAddEditTxSheet = true
                        },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.testTag("fab_add_transaction")
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = "नया लेन-देन जोड़ें")
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(modifier = Modifier.fillMaxHeight()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        AppTab.entries.forEach { tab ->
                            val selected = currentTab == tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { currentTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    when (val s = uiState) {
                        is UiState.Loading -> {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator()
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "आपका हिसाब लोड हो रहा है...",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        is UiState.Error -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(24.dp),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "डेटा लोड करने में समस्या",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = s.message,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }

                        is UiState.Success -> {
                            val data = s.data
                            val displayName = data.profile?.displayName?.takeIf { it.isNotBlank() }
                                ?: "मेरा खाता"

                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .widthIn(max = 820.dp)
                            ) {
                                when (currentTab) {
                                    AppTab.DASHBOARD -> DashboardScreen(
                                        state = data,
                                        userDisplayName = displayName,
                                        isOnline = isOnline,
                                        smartParseState = smartParseState,
                                        onAnalyzeSmartText = { input ->
                                            viewModel.analyzeSmartEntry(input, isOnline)
                                        },
                                        onUseOfflineFallback = { fallback ->
                                            viewModel.useOfflineFallback(fallback)
                                        },
                                        onClearSmartError = { viewModel.clearSmartParseState() },
                                        onOpenAddExpense = {
                                            editingTx = null
                                            defaultTxType = TransactionType.EXPENSE
                                            showAddEditTxSheet = true
                                        },
                                        onOpenAddIncome = {
                                            editingTx = null
                                            defaultTxType = TransactionType.INCOME
                                            showAddEditTxSheet = true
                                        },
                                        onOpenAddUdhar = { showQuickUdharSheet = true },
                                        onOpenSettings = { showSettingsSheet = true },
                                        onOpenApkDownload = { showApkSheet = true },
                                        onNavigateToHistory = { currentTab = AppTab.HISTORY },
                                        onNavigateToUdhar = { currentTab = AppTab.UDHAR },
                                        onEditTransaction = { tx ->
                                            editingTx = tx
                                            showAddEditTxSheet = true
                                        },
                                        onDeleteTransaction = { tx -> deletingTx = tx }
                                    )

                                    AppTab.HISTORY -> HistoryScreen(
                                        transactions = data.transactions,
                                        onEditTransaction = { tx ->
                                            editingTx = tx
                                            showAddEditTxSheet = true
                                        },
                                        onDeleteTransaction = { tx -> deletingTx = tx }
                                    )

                                    AppTab.UDHAR -> UdharScreen(
                                        summaries = data.personUdharSummaries,
                                        totalReceivablePaise = data.summary.totalUdharReceivablePaise,
                                        totalPayablePaise = data.summary.totalUdharPayablePaise,
                                        isSaving = isSaving,
                                        onSaveUdharEntry = { id, isEdit, name, phone, type, amountPaise, dateKey, dueDateKey, note, onDone ->
                                            viewModel.saveUdharEntry(
                                                entryId = id,
                                                isEdit = isEdit,
                                                personName = name,
                                                phone = phone,
                                                entryType = type,
                                                amountPaise = amountPaise,
                                                dateKey = dateKey,
                                                dueDateKey = dueDateKey,
                                                note = note,
                                                onComplete = onDone
                                            )
                                        },
                                        onDeleteUdharEntry = { id ->
                                            viewModel.deleteUdharEntry(id)
                                        }
                                    )

                                    AppTab.REPORTS -> ReportScreen(
                                        report = data.monthlyReport,
                                        udharSummaries = data.personUdharSummaries,
                                        userName = displayName,
                                        onSelectMonth = { mKey -> viewModel.selectReportMonth(mKey) },
                                        onShowMessage = { msg ->
                                            scope.launch { snackbarHostState.showSnackbar(msg) }
                                        }
                                    )
                                }
                            }

                            if (showAddEditTxSheet) {
                                AddEditTransactionSheet(
                                    initialTransaction = editingTx,
                                    initialType = defaultTxType,
                                    existingTransactions = data.transactions,
                                    isSaving = isSaving,
                                    onDismiss = {
                                        showAddEditTxSheet = false
                                        editingTx = null
                                    },
                                    onSave = { txId, isEdit, type, amountPaise, category, note, dateKey, source ->
                                        viewModel.saveTransaction(
                                            transactionId = txId,
                                            isEdit = isEdit,
                                            type = type,
                                            amountPaise = amountPaise,
                                            category = category,
                                            note = note,
                                            dateKey = dateKey,
                                            source = source,
                                            onComplete = {
                                                showAddEditTxSheet = false
                                                editingTx = null
                                            }
                                        )
                                    }
                                )
                            }

                            if (showQuickUdharSheet) {
                                AddEditUdharSheet(
                                    initialEntry = null,
                                    prefillPersonName = "",
                                    prefillPhone = "",
                                    prefillType = UdharEntryType.GIVEN,
                                    existingPersonNames = data.personUdharSummaries.map { it.personName },
                                    isSaving = isSaving,
                                    onDismiss = { showQuickUdharSheet = false },
                                    onSave = { id, isEdit, name, phone, type, amountPaise, dateKey, dueDateKey, note ->
                                        viewModel.saveUdharEntry(
                                            entryId = id,
                                            isEdit = isEdit,
                                            personName = name,
                                            phone = phone,
                                            entryType = type,
                                            amountPaise = amountPaise,
                                            dateKey = dateKey,
                                            dueDateKey = dueDateKey,
                                            note = note,
                                            onComplete = { showQuickUdharSheet = false }
                                        )
                                    }
                                )
                            }

                            if (showSettingsSheet) {
                                SettingsBottomSheet(
                                    profile = data.profile,
                                    transactions = data.transactions,
                                    udharEntries = data.udharEntries,
                                    isSaving = isSaving,
                                    onDismiss = { showSettingsSheet = false },
                                    onSaveSettings = { name, openPaise, budgetPaise ->
                                        viewModel.updateProfileSettings(
                                            displayName = name,
                                            openingBalancePaise = openPaise,
                                            monthlyBudgetPaise = budgetPaise,
                                            onComplete = { showSettingsSheet = false }
                                        )
                                    },
                                    onOpenApkDownload = { showApkSheet = true },
                                    onShowMessage = { msg ->
                                        scope.launch { snackbarHostState.showSnackbar(msg) }
                                    }
                                )
                            }

                            if (showApkSheet) {
                                ApkDownloadBottomSheet(
                                    onDismiss = { showApkSheet = false },
                                    onShowMessage = { msg ->
                                        scope.launch { snackbarHostState.showSnackbar(msg) }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    val parsedState = smartParseState as? SmartParseUiState.Parsed
    if (parsedState != null) {
        SmartParseConfirmationSheet(
            parsed = parsedState.result,
            isSaving = isSaving,
            onDismiss = { viewModel.clearSmartParseState() },
            onConfirmTransaction = { txId, type, amountPaise, category, note, dateKey ->
                viewModel.saveTransaction(
                    transactionId = txId,
                    isEdit = false,
                    type = type,
                    amountPaise = amountPaise,
                    category = category,
                    note = note,
                    dateKey = dateKey,
                    source = EntrySource.SMART_TEXT,
                    onComplete = { viewModel.clearSmartParseState() }
                )
            },
            onConfirmUdhar = { entryId, personName, entryType, amountPaise, dateKey, note ->
                viewModel.saveUdharEntry(
                    entryId = entryId,
                    isEdit = false,
                    personName = personName,
                    phone = null,
                    entryType = entryType,
                    amountPaise = amountPaise,
                    dateKey = dateKey,
                    dueDateKey = null,
                    note = note,
                    onComplete = { viewModel.clearSmartParseState() }
                )
            }
        )
    }

    deletingTx?.let { tx ->
        DeleteConfirmDialog(
            title = "लेन-देन हटाएं?",
            message = "${tx.category} (${IndianFormatters.formatInr(tx.amountPaise)} • ${IndianFormatters.formatIndianDate(tx.dateKey)}) स्थायी रूप से हटा दिया जाएगा।",
            onDismiss = { deletingTx = null },
            onConfirm = {
                viewModel.deleteTransaction(tx.id)
                deletingTx = null
            }
        )
    }
}
