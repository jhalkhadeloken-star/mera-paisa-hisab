package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.InstallMobile
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalFinanceColors
import com.example.util.ReportExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApkDownloadBottomSheet(
    onDismiss: () -> Unit,
    onShowMessage: (String) -> Unit
) {
    BackHandler { onDismiss() }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val financeColors = LocalFinanceColors.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val apkInfo = remember(context) { ReportExporter.getInstalledApkInfo(context) }
    var isWorking by remember { mutableStateOf(false) }

    val saveApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { uri ->
        if (uri != null) {
            isWorking = true
            scope.launch {
                val res = withContext(Dispatchers.IO) {
                    ReportExporter.copyInstalledApkToUri(context, uri)
                }
                isWorking = false
                res.onSuccess { bytes ->
                    val mb = String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
                    onShowMessage("APK फ़ाइल सेव हो गई ($mb)। Files/Downloads में खोलकर इंस्टॉल करें।")
                }.onFailure { err ->
                    onShowMessage("APK सेव नहीं हो सकी: ${err.localizedMessage ?: "अज्ञात त्रुटि"}")
                }
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.InstallMobile,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "APK डाउनलोड और इंस्टॉल",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "संस्करण v${apkInfo.versionName} • बिना लॉगिन ऑफ़लाइन ऐप",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "बंद करें")
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (apkInfo.isAvailable) {
                val sizeMb = String.format(Locale.US, "%.1f MB", apkInfo.sizeBytes / (1024.0 * 1024.0))
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = financeColors.incomeContainer.copy(alpha = 0.55f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Android,
                            contentDescription = null,
                            tint = financeColors.income,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "साइन किया गया Android APK तैयार है",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${apkInfo.suggestedFileName} • आकार: $sizeMb",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { saveApkLauncher.launch(apkInfo.suggestedFileName) },
                    enabled = !isWorking,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("download_apk_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Download,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isWorking) "APK तैयार हो रही है..." else "APK फ़ोन में डाउनलोड / सेव करें",
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedButton(
                    onClick = {
                        isWorking = true
                        scope.launch {
                            val res = withContext(Dispatchers.IO) {
                                ReportExporter.exportInstalledApkForShare(context)
                            }
                            isWorking = false
                            res.onSuccess { uri ->
                                ReportExporter.shareFile(
                                    context = context,
                                    uri = uri,
                                    mimeType = "application/vnd.android.package-archive",
                                    title = "Mera Paisa Hisab APK शेयर करें"
                                )
                            }.onFailure { err ->
                                onShowMessage("APK शेयर नहीं हो सकी: ${err.localizedMessage ?: "अज्ञात त्रुटि"}")
                            }
                        }
                    },
                    enabled = !isWorking,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("share_apk_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Share,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("APK किसी अन्य फ़ोन पर शेयर करें", fontWeight = FontWeight.SemiBold)
                }
            } else {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (apkInfo.isSplitBundle) {
                                "यह ऐप Split App Bundle के रूप में इंस्टॉल है। पूरा साइन किया हुआ APK डाउनलोड करने के लिए ऊपर AI Studio के Settings मेन्यू से Generate APK विकल्प चुनें।"
                            } else {
                                "APK फ़ाइल इस समय सीधे डिवाइस से उपलब्ध नहीं है। साइन किया हुआ APK डाउनलोड करने के लिए AI Studio के Settings मेन्यू से APK जनरेट करें।"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Installation instructions card
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.VerifiedUser,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "फ़ोन में APK इंस्टॉल करने के आसान चरण",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    InstallStepRow("1.", "ऊपर 'APK फ़ोन में डाउनलोड / सेव करें' बटन दबाकर Downloads फ़ोल्डर में सेव करें (या AI Studio के Settings मेन्यू से APK डाउनलोड करें)।")
                    InstallStepRow("2.", "फ़ोन का 'Files' या 'Downloads' ऐप खोलें और '${apkInfo.suggestedFileName}' फ़ाइल पर टैप करें।")
                    InstallStepRow("3.", "यदि Android सुरक्षा पूछे, तो 'Install unknown apps / अज्ञात ऐप्स की अनुमति' चालू करें और 'Install' दबाएँ।")
                    InstallStepRow("4.", "इंस्टॉल होने के बाद ऐप बिना इंटरनेट और बिना Gmail लॉगिन के चलेगा। अपडेट करने पर भी आपका पुराना हिसाब सुरक्षित रहेगा।")
                }
            }
        }
    }
}

@Composable
private fun InstallStepRow(stepNumber: String, text: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = stepNumber,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.width(20.dp)
        )
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
