package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Emerald Ledger Palette
val EmeraldPrimary = Color(0xFF0D4F44)
val EmeraldPrimaryLight = Color(0xFF157A69)
val EmeraldContainerLight = Color(0xFFD5F2EA)
val OnEmeraldContainerLight = Color(0xFF052E27)

val EmeraldPrimaryDark = Color(0xFF6EE7B7)
val EmeraldContainerDark = Color(0xFF064E3B)
val OnEmeraldContainerDark = Color(0xFFD1FAE5)

// Secondary Warm Amber / Saffron Accent
val AmberSecondary = Color(0xFFD97706)
val AmberContainerLight = Color(0xFFFEF3C7)
val OnAmberContainerLight = Color(0xFF451A03)

val AmberSecondaryDark = Color(0xFFFBBF24)
val AmberContainerDark = Color(0xFF78350F)
val OnAmberContainerDark = Color(0xFFFEF3C7)

// Surface & Background Tokens
val SurfaceBgLight = Color(0xFFF4F8F6)
val SurfaceCardLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFE7EFEC)
val OutlineLight = Color(0xFFC5D3CE)
val OnSurfaceLight = Color(0xFF10211D)
val OnSurfaceVariantLight = Color(0xFF4B635C)

val SurfaceBgDark = Color(0xFF0B1412)
val SurfaceCardDark = Color(0xFF13201D)
val SurfaceVariantDark = Color(0xFF1C2E2A)
val OutlineDark = Color(0xFF334B45)
val OnSurfaceDark = Color(0xFFE6F1EE)
val OnSurfaceVariantDark = Color(0xFFA0B8B1)

// Semantic Finance Colors (Green = Income, Red = Expense, Blue = Savings, Amber = Udhar)
val IncomeGreenLight = Color(0xFF15803D)
val IncomeGreenContainerLight = Color(0xFFDCFCE7)
val OnIncomeGreenContainerLight = Color(0xFF052E16)

val IncomeGreenDark = Color(0xFF4ADE80)
val IncomeGreenContainerDark = Color(0xFF14532D)
val OnIncomeGreenContainerDark = Color(0xFFDCFCE7)

val ExpenseRedLight = Color(0xFFDC2626)
val ExpenseRedContainerLight = Color(0xFFFEE2E2)
val OnExpenseRedContainerLight = Color(0xFF450A0A)

val ExpenseRedDark = Color(0xFFF87171)
val ExpenseRedContainerDark = Color(0xFF7F1D1D)
val OnExpenseRedContainerDark = Color(0xFFFEE2E2)

val SavingsBlueLight = Color(0xFF2563EB)
val SavingsBlueContainerLight = Color(0xFFDBEAFE)
val OnSavingsBlueContainerLight = Color(0xFF1E3A8A)

val SavingsBlueDark = Color(0xFF60A5FA)
val SavingsBlueContainerDark = Color(0xFF1E3A8A)
val OnSavingsBlueContainerDark = Color(0xFFDBEAFE)

// Chart Category Palette
val ChartColors = listOf(
    Color(0xFFEF4444), // Red
    Color(0xFFF59E0B), // Amber
    Color(0xFF2563EB), // Blue
    Color(0xFF10B981), // Emerald
    Color(0xFF8B5CF6), // Violet
    Color(0xFFEC4899), // Pink
    Color(0xFF06B6D4), // Cyan
    Color(0xFFF97316), // Orange
    Color(0xFF6366F1), // Indigo
    Color(0xFF64748B)  // Slate
)
