package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.SmartEntryParser
import com.example.data.ai.SmartParseResult
import com.example.data.model.CategoryBreakdown
import com.example.data.model.DailyBarPoint
import com.example.data.model.DashboardSummary
import com.example.data.model.EntrySource
import com.example.data.model.FinanceCategories
import com.example.data.model.LedgerTransaction
import com.example.data.model.MonthlyReportData
import com.example.data.model.MonthlySummaryRow
import com.example.data.model.PersonUdharSummary
import com.example.data.model.TransactionType
import com.example.data.model.UdharEntry
import com.example.data.model.UdharEntryType
import com.example.data.model.UserProfile
import com.example.data.repository.FinanceRepository
import com.example.util.IndianFormatters
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

sealed interface SmartParseUiState {
    data object Idle : SmartParseUiState
    data object Loading : SmartParseUiState
    data class Parsed(val result: SmartParseResult) : SmartParseUiState
    data class Error(val message: String, val offlineFallback: SmartParseResult?) : SmartParseUiState
}

data class MainDashboardState(
    val profile: UserProfile?,
    val summary: DashboardSummary,
    val transactions: List<LedgerTransaction>,
    val udharEntries: List<UdharEntry>,
    val personUdharSummaries: List<PersonUdharSummary>,
    val weeklyPoints: List<DailyBarPoint>,
    val currentMonthBreakdowns: List<CategoryBreakdown>,
    val monthlyReport: MonthlyReportData
)

class FinanceViewModel(
    private val repository: FinanceRepository,
    private val smartParser: SmartEntryParser
) : ViewModel() {

    private val _selectedMonthKey = MutableStateFlow(IndianFormatters.currentMonthKey())
    val selectedMonthKey: StateFlow<String> = _selectedMonthKey.asStateFlow()

    private val _smartParseState = MutableStateFlow<SmartParseUiState>(SmartParseUiState.Idle)
    val smartParseState: StateFlow<SmartParseUiState> = _smartParseState.asStateFlow()

    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events = _events.asSharedFlow()

    init {
        viewModelScope.launch {
            repository.ensureUserProfile()
        }
    }

    private val profileFlow = repository.observeProfile()
        .map<UserProfile?, UiState<UserProfile?>> { UiState.Success(it) }
        .catch { error ->
            if (error is CancellationException) throw error
            Log.w(TAG, "Error observing profile", error)
            emit(UiState.Error(error.message ?: "प्रोफ़ाइल लोड करने में समस्या आई।"))
        }

    private val transactionsFlow = repository.observeTransactions()
        .map<List<LedgerTransaction>, UiState<List<LedgerTransaction>>> { UiState.Success(it) }
        .catch { error ->
            if (error is CancellationException) throw error
            Log.w(TAG, "Error observing transactions", error)
            emit(UiState.Error(error.message ?: "लेन-देन लोड करने में समस्या आई।"))
        }

    private val udharFlow = repository.observeUdharEntries()
        .map<List<UdharEntry>, UiState<List<UdharEntry>>> { UiState.Success(it) }
        .catch { error ->
            if (error is CancellationException) throw error
            Log.w(TAG, "Error observing udhar", error)
            emit(UiState.Error(error.message ?: "उधार विवरण लोड करने में समस्या आई।"))
        }

    val mainState: StateFlow<UiState<MainDashboardState>> = combine(
        profileFlow,
        transactionsFlow,
        udharFlow,
        _selectedMonthKey
    ) { profileState, txState, udharState, monthKey ->
        when {
            txState is UiState.Error -> UiState.Error(txState.message)
            udharState is UiState.Error -> UiState.Error(udharState.message)
            profileState is UiState.Error -> UiState.Error(profileState.message)
            txState is UiState.Loading || udharState is UiState.Loading -> UiState.Loading
            else -> {
                val profile = (profileState as? UiState.Success)?.data
                val txs = (txState as UiState.Success).data
                val udhars = (udharState as UiState.Success).data
                UiState.Success(buildDashboardState(profile, txs, udhars, monthKey))
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = UiState.Loading
    )

    fun selectReportMonth(monthKey: String) {
        _selectedMonthKey.value = monthKey
    }

    fun analyzeSmartEntry(inputText: String, isOnline: Boolean) {
        val cleaned = inputText.trim()
        if (cleaned.isEmpty()) {
            _events.tryEmit("कृपया पहले कोई संदेश लिखें, जैसे: \"Aaj 100 rupaye kharch hue\"")
            return
        }
        viewModelScope.launch {
            _smartParseState.value = SmartParseUiState.Loading
            val result = smartParser.parseSmartInput(cleaned, isOnline)
            result.onSuccess { parsed ->
                _smartParseState.value = SmartParseUiState.Parsed(parsed)
            }.onFailure { err ->
                val offlineSuggestion = smartParser.parseOffline(cleaned)
                val friendlyMsg = err.localizedMessage?.takeIf { it.isNotBlank() }
                    ?: "स्मार्ट पार्सिंग में समस्या आई।"
                _smartParseState.value = SmartParseUiState.Error(
                    message = "ऑनलाइन AI त्रुटि: $friendlyMsg",
                    offlineFallback = offlineSuggestion
                )
            }
        }
    }

    fun useOfflineFallback(fallback: SmartParseResult) {
        _smartParseState.value = SmartParseUiState.Parsed(fallback)
    }

    fun clearSmartParseState() {
        _smartParseState.value = SmartParseUiState.Idle
    }

    fun saveTransaction(
        transactionId: String,
        isEdit: Boolean,
        type: TransactionType,
        amountPaise: Long,
        category: String,
        note: String,
        dateKey: String,
        source: EntrySource,
        onComplete: () -> Unit = {}
    ) {
        if (_isSaving.value) return
        viewModelScope.launch {
            _isSaving.value = true
            try {
                val res = repository.saveTransaction(
                    transactionId = transactionId,
                    isEdit = isEdit,
                    type = type,
                    amountPaise = amountPaise,
                    category = category,
                    note = note,
                    dateKey = dateKey,
                    source = source
                )
                res.onSuccess {
                    _events.tryEmit(if (isEdit) "लेन-देन अपडेट हो गया।" else "लेन-देन सफलतापूर्वक सहेजा गया।")
                    onComplete()
                }.onFailure { err ->
                    _events.tryEmit(err.localizedMessage ?: "लेन-देन सहेजने में त्रुटि हुई।")
                }
            } finally {
                _isSaving.value = false
            }
        }
    }

    fun deleteTransaction(transactionId: String) {
        if (_isSaving.value) return
        viewModelScope.launch {
            _isSaving.value = true
            try {
                val res = repository.deleteTransaction(transactionId)
                res.onSuccess {
                    _events.tryEmit("लेन-देन हटा दिया गया।")
                }.onFailure { err ->
                    _events.tryEmit(err.localizedMessage ?: "लेन-देन हटाने में त्रुटि हुई।")
                }
            } finally {
                _isSaving.value = false
            }
        }
    }

    fun saveUdharEntry(
        entryId: String,
        isEdit: Boolean,
        personName: String,
        phone: String?,
        entryType: UdharEntryType,
        amountPaise: Long,
        dateKey: String,
        dueDateKey: String?,
        note: String,
        onComplete: () -> Unit = {}
    ) {
        if (_isSaving.value) return
        viewModelScope.launch {
            _isSaving.value = true
            try {
                val res = repository.saveUdharEntry(
                    entryId = entryId,
                    isEdit = isEdit,
                    personName = personName,
                    phone = phone,
                    entryType = entryType,
                    amountPaise = amountPaise,
                    dateKey = dateKey,
                    dueDateKey = dueDateKey,
                    note = note
                )
                res.onSuccess {
                    _events.tryEmit(if (isEdit) "उधार विवरण अपडेट हो गया।" else "उधार एंट्री सफलतापूर्वक दर्ज हुई।")
                    onComplete()
                }.onFailure { err ->
                    _events.tryEmit(err.localizedMessage ?: "उधार दर्ज करने में त्रुटि हुई।")
                }
            } finally {
                _isSaving.value = false
            }
        }
    }

    fun deleteUdharEntry(entryId: String) {
        if (_isSaving.value) return
        viewModelScope.launch {
            _isSaving.value = true
            try {
                val res = repository.deleteUdharEntry(entryId)
                res.onSuccess {
                    _events.tryEmit("उधार एंट्री हटा दी गई।")
                }.onFailure { err ->
                    _events.tryEmit(err.localizedMessage ?: "उधार एंट्री हटाने में त्रुटि हुई।")
                }
            } finally {
                _isSaving.value = false
            }
        }
    }

    fun updateProfileSettings(
        displayName: String,
        openingBalancePaise: Long,
        monthlyBudgetPaise: Long,
        onComplete: () -> Unit = {}
    ) {
        if (_isSaving.value) return
        viewModelScope.launch {
            _isSaving.value = true
            try {
                val res = repository.updateProfileSettings(
                    displayName = displayName,
                    openingBalancePaise = openingBalancePaise,
                    monthlyBudgetPaise = monthlyBudgetPaise
                )
                res.onSuccess {
                    _events.tryEmit("सेटिंग्स सहेजी गईं।")
                    onComplete()
                }.onFailure { err ->
                    _events.tryEmit(err.localizedMessage ?: "सेटिंग्स सहेजने में त्रुटि हुई।")
                }
            } finally {
                _isSaving.value = false
            }
        }
    }

    private fun buildDashboardState(
        profile: UserProfile?,
        transactions: List<LedgerTransaction>,
        udharEntries: List<UdharEntry>,
        selectedMonthKey: String
    ): MainDashboardState {
        val todayKey = IndianFormatters.todayDateKey()
        val currentMonthKey = IndianFormatters.currentMonthKey()

        var todayExpense = 0L
        var todayIncome = 0L
        var monthExpense = 0L
        var monthIncome = 0L
        var allTimeExpense = 0L
        var allTimeIncome = 0L

        for (tx in transactions) {
            val isIncome = tx.transactionType() == TransactionType.INCOME
            if (isIncome) {
                allTimeIncome += tx.amountPaise
                if (tx.dateKey == todayKey) todayIncome += tx.amountPaise
                if (tx.monthKey == currentMonthKey) monthIncome += tx.amountPaise
            } else {
                allTimeExpense += tx.amountPaise
                if (tx.dateKey == todayKey) todayExpense += tx.amountPaise
                if (tx.monthKey == currentMonthKey) monthExpense += tx.amountPaise
            }
        }

        val personGroups = udharEntries.groupBy { it.personKey.ifBlank { it.personName.trim().lowercase() } }
        val personSummaries = personGroups.map { (key, list) ->
            var given = 0L
            var borrowed = 0L
            var repaidToMe = 0L
            var repaidByMe = 0L
            for (entry in list) {
                when (entry.udharType()) {
                    UdharEntryType.GIVEN -> given += entry.amountPaise
                    UdharEntryType.BORROWED -> borrowed += entry.amountPaise
                    UdharEntryType.REPAYMENT_RECEIVED -> repaidToMe += entry.amountPaise
                    UdharEntryType.REPAYMENT_PAID -> repaidByMe += entry.amountPaise
                }
            }
            val net = (given - repaidToMe) - (borrowed - repaidByMe)
            val latestEntry = list.maxByOrNull { it.dateKey }
            val displayName = latestEntry?.personName ?: list.first().personName
            val phone = list.firstNotNullOfOrNull { it.phone?.takeIf { p -> p.isNotBlank() } }
            PersonUdharSummary(
                personKey = key,
                personName = displayName,
                phone = phone,
                totalGivenPaise = given,
                totalBorrowedPaise = borrowed,
                totalRepaidToMePaise = repaidToMe,
                totalRepaidByMePaise = repaidByMe,
                netBalancePaise = net,
                latestDateKey = latestEntry?.dateKey ?: "",
                entries = list
            )
        }.sortedWith(
            compareByDescending<PersonUdharSummary> { kotlin.math.abs(it.netBalancePaise) }
                .thenByDescending { it.latestDateKey }
        )

        var totalReceivable = 0L
        var totalPayable = 0L
        for (p in personSummaries) {
            if (p.netBalancePaise > 0) totalReceivable += p.netBalancePaise
            else if (p.netBalancePaise < 0) totalPayable += -p.netBalancePaise
        }

        val openingBalance = profile?.openingBalancePaise ?: 0L
        val monthlyBudget = profile?.monthlyBudgetPaise ?: 0L
        val availableBalance = openingBalance + allTimeIncome - allTimeExpense

        val summary = DashboardSummary(
            todayExpensePaise = todayExpense,
            todayIncomePaise = todayIncome,
            todaySavingsPaise = todayIncome - todayExpense,
            monthExpensePaise = monthExpense,
            monthIncomePaise = monthIncome,
            monthSavingsPaise = monthIncome - monthExpense,
            totalUdharReceivablePaise = totalReceivable,
            totalUdharPayablePaise = totalPayable,
            netPendingUdharPaise = totalReceivable - totalPayable,
            availableBalancePaise = availableBalance,
            openingBalancePaise = openingBalance,
            monthlyBudgetPaise = monthlyBudget
        )

        val weeklyPoints = (6 downTo 0).map { daysAgo ->
            val dk = IndianFormatters.daysAgoDateKey(daysAgo)
            val dayTxs = transactions.filter { it.dateKey == dk }
            val inc = dayTxs.filter { it.transactionType() == TransactionType.INCOME }.sumOf { it.amountPaise }
            val exp = dayTxs.filter { it.transactionType() == TransactionType.EXPENSE }.sumOf { it.amountPaise }
            DailyBarPoint(
                dateKey = dk,
                shortLabel = if (daysAgo == 0) "आज" else IndianFormatters.formatShortDayLabel(dk),
                incomePaise = inc,
                expensePaise = exp
            )
        }

        val currentMonthBreakdowns = buildCategoryBreakdowns(
            transactions.filter { it.monthKey == currentMonthKey && it.transactionType() == TransactionType.EXPENSE }
        )

        val allMonthKeys = (transactions.map { it.monthKey } + listOf(currentMonthKey, selectedMonthKey))
            .filter { it.matches(Regex("^\\d{4}-\\d{2}$")) }
            .distinct()
            .sortedDescending()

        val selectedMonthTxs = transactions.filter { it.monthKey == selectedMonthKey }
        val selIncome = selectedMonthTxs.filter { it.transactionType() == TransactionType.INCOME }.sumOf { it.amountPaise }
        val selExpense = selectedMonthTxs.filter { it.transactionType() == TransactionType.EXPENSE }.sumOf { it.amountPaise }
        val selSavings = selIncome - selExpense
        val savingsRate = if (selIncome > 0L) {
            ((selSavings.toDouble() / selIncome.toDouble()) * 100.0).toInt().coerceIn(-999, 100)
        } else 0

        val selBreakdowns = buildCategoryBreakdowns(
            selectedMonthTxs.filter { it.transactionType() == TransactionType.EXPENSE }
        )

        val monthSummaries = allMonthKeys.map { mKey ->
            val mTxs = transactions.filter { it.monthKey == mKey }
            val mInc = mTxs.filter { it.transactionType() == TransactionType.INCOME }.sumOf { it.amountPaise }
            val mExp = mTxs.filter { it.transactionType() == TransactionType.EXPENSE }.sumOf { it.amountPaise }
            MonthlySummaryRow(
                monthKey = mKey,
                monthTitle = IndianFormatters.formatIndianMonthTitle(mKey),
                incomePaise = mInc,
                expensePaise = mExp,
                savingsPaise = mInc - mExp,
                transactionCount = mTxs.size
            )
        }

        val report = MonthlyReportData(
            selectedMonthKey = selectedMonthKey,
            selectedMonthTitle = IndianFormatters.formatIndianMonthTitle(selectedMonthKey),
            monthIncomePaise = selIncome,
            monthExpensePaise = selExpense,
            monthSavingsPaise = selSavings,
            savingsRatePercent = savingsRate,
            categoryBreakdowns = selBreakdowns,
            monthTransactions = selectedMonthTxs,
            previousMonths = monthSummaries,
            availableMonthKeys = allMonthKeys
        )

        return MainDashboardState(
            profile = profile,
            summary = summary,
            transactions = transactions,
            udharEntries = udharEntries,
            personUdharSummaries = personSummaries,
            weeklyPoints = weeklyPoints,
            currentMonthBreakdowns = currentMonthBreakdowns,
            monthlyReport = report
        )
    }

    private fun buildCategoryBreakdowns(expenseTxs: List<LedgerTransaction>): List<CategoryBreakdown> {
        val total = expenseTxs.sumOf { it.amountPaise }
        if (total <= 0L) return emptyList()
        return expenseTxs
            .groupBy { it.category.ifBlank { "अन्य" } }
            .map { (cat, list) ->
                val sum = list.sumOf { it.amountPaise }
                val info = FinanceCategories.infoFor(cat, TransactionType.EXPENSE)
                CategoryBreakdown(
                    category = cat,
                    amountPaise = sum,
                    percentage = (sum.toFloat() / total.toFloat()) * 100f,
                    color = info.color
                )
            }
            .sortedByDescending { it.amountPaise }
    }

    private companion object {
        const val TAG = "FinanceVM"
    }
}
