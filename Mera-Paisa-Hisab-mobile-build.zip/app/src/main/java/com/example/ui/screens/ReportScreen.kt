package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.MonthlyReportData
import com.example.data.model.PersonUdharSummary
import com.example.ui.components.CategoryDonutChart
import com.example.ui.components.MonthlyTrendChart
import com.example.ui.theme.LocalFinanceColors
import com.example.util.IndianFormatters
import com.example.util.ReportExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ReportScreen(
    report: MonthlyReportData,
    udharSummaries: List<PersonUdharSummary>,
    userName: String,
    onSelectMonth: (String) -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val financeColors = LocalFinanceColors.current
    var isExporting by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "मासिक वित्तीय रिपोर्ट",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    report.availableMonthKeys.forEach { mKey ->
                        FilterChip(
                            selected = mKey == report.selectedMonthKey,
                            onClick = { onSelectMonth(mKey) },
                            label = { Text(IndianFormatters.formatIndianMonthTitle(mKey)) }
                        )
                    }
                }
            }
        }

        // Export Action Row (PDF + Excel .xlsx)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        if (isExporting) return@Button
                        isExporting = true
                        scope.launch {
                            val result = withContext(Dispatchers.IO) {
                                ReportExporter.exportMonthlyPdf(context, report, userName)
                            }
                            isExporting = false
                            result.onSuccess { uri ->
                                ReportExporter.shareFile(
                                    context = context,
                                    uri = uri,
                                    mimeType = "application/pdf",
                                    title = "PDF रिपोर्ट साझा करें / सहेजें"
                                )
                            }.onFailure { err ->
                                onShowMessage("PDF बनाने में त्रुटि: ${err.localizedMessage ?: "अज्ञात त्रुटि"}")
                            }
                        }
                    },
                    enabled = !isExporting,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = financeColors.expense),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("export_pdf_button")
                ) {
                    Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("PDF एक्सपोर्ट", style = MaterialTheme.typography.labelLarge)
                }

                OutlinedButton(
                    onClick = {
                        if (isExporting) return@OutlinedButton
                        isExporting = true
                        scope.launch {
                            val result = withContext(Dispatchers.IO) {
                                ReportExporter.exportMonthlyExcel(context, report, udharSummaries)
                            }
                            isExporting = false
                            result.onSuccess { uri ->
                                ReportExporter.shareFile(
                                    context = context,
                                    uri = uri,
                                    mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                    title = "Excel (.xlsx) रिपोर्ट साझा करें / सहेजें"
                                )
                            }.onFailure { err ->
                                onShowMessage("Excel बनाने में त्रुटि: ${err.localizedMessage ?: "अज्ञात त्रुटि"}")
                            }
                        }
                    },
                    enabled = !isExporting,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("export_excel_button")
                ) {
                    Icon(
                        Icons.Rounded.TableChart,
                        contentDescription = null,
                        tint = financeColors.income,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Excel (.xlsx)",
                        style = MaterialTheme.typography.labelLarge,
                        color = financeColors.income
                    )
                }
            }
        }

        // Monthly Income, Expense, Savings Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = financeColors.incomeContainer,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "मासिक आय",
                            style = MaterialTheme.typography.labelSmall,
                            color = financeColors.onIncomeContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = IndianFormatters.formatInr(report.monthIncomePaise),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = financeColors.income
                        )
                    }
                }
                Surface(
                    color = financeColors.expenseContainer,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "मासिक खर्च",
                            style = MaterialTheme.typography.labelSmall,
                            color = financeColors.onExpenseContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = IndianFormatters.formatInr(report.monthExpensePaise),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = financeColors.expense
                        )
                    }
                }
                Surface(
                    color = financeColors.savingsContainer,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "बचत (${report.savingsRatePercent}%)",
                            style = MaterialTheme.typography.labelSmall,
                            color = financeColors.onSavingsContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = IndianFormatters.formatInr(report.monthSavingsPaise),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = financeColors.savings
                        )
                    }
                }
            }
        }

        // Category-wise Expense Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "${report.selectedMonthTitle} — श्रेणीवार खर्च",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    if (report.categoryBreakdowns.isEmpty()) {
                        Text(
                            text = "इस माह में कोई खर्च दर्ज नहीं हुआ है।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        CategoryDonutChart(
                            breakdowns = report.categoryBreakdowns,
                            totalExpensePaise = report.monthExpensePaise
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        report.categoryBreakdowns.forEach { cat ->
                            Column(modifier = Modifier.padding(vertical = 5.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = cat.category,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = "${IndianFormatters.formatInr(cat.amountPaise)} (${"%.1f".format(cat.percentage)}%)",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress = { (cat.percentage / 100f).coerceIn(0f, 1f) },
                                    color = cat.color,
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                    strokeCap = StrokeCap.Round,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(7.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                )
                            }
                        }
                    }
                }
            }
        }

        // Previous Months Comparison Chart & Table
        if (report.previousMonths.isNotEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "पिछले महीनों का तुलनात्मक ग्राफ़",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        MonthlyTrendChart(months = report.previousMonths)
                    }
                }
            }

            item {
                Text(
                    text = "महीने-वार रिकॉर्ड",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            items(report.previousMonths, key = { it.monthKey }) { row ->
                val isSelected = row.monthKey == report.selectedMonthKey
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) {
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                        } else {
                            MaterialTheme.colorScheme.surface
                        }
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectMonth(row.monthKey) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = row.monthTitle,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${row.transactionCount} लेन-देन",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "आय: ${IndianFormatters.formatInr(row.incomePaise)}  •  खर्च: ${IndianFormatters.formatInr(row.expensePaise)}",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = "बचत: ${IndianFormatters.formatInr(row.savingsPaise)}",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = if (row.savingsPaise >= 0) financeColors.savings else financeColors.expense
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(82.dp)) }
    }
}
