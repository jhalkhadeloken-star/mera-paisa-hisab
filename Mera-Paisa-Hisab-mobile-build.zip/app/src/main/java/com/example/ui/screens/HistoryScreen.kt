package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarToday
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.LedgerTransaction
import com.example.data.model.TransactionType
import com.example.ui.components.IndianDatePickerDialog
import com.example.ui.components.TransactionRowCard
import com.example.ui.theme.LocalFinanceColors
import com.example.util.IndianFormatters

@Composable
fun HistoryScreen(
    transactions: List<LedgerTransaction>,
    onEditTransaction: (LedgerTransaction) -> Unit,
    onDeleteTransaction: (LedgerTransaction) -> Unit,
    modifier: Modifier = Modifier
) {
    val financeColors = LocalFinanceColors.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedTypeFilter by remember { mutableStateOf<TransactionType?>(null) }
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var selectedDateKey by remember { mutableStateOf<String?>(null) }
    var showDatePicker by remember { mutableStateOf(false) }

    val availableCategories = remember(transactions, selectedTypeFilter) {
        transactions
            .filter { selectedTypeFilter == null || it.transactionType() == selectedTypeFilter }
            .map { it.category }
            .distinct()
    }

    val filteredTransactions = remember(
        transactions,
        searchQuery,
        selectedTypeFilter,
        selectedCategory,
        selectedDateKey
    ) {
        val q = searchQuery.trim().lowercase()
        transactions.filter { tx ->
            val matchesType = selectedTypeFilter == null || tx.transactionType() == selectedTypeFilter
            val matchesCat = selectedCategory == null || tx.category == selectedCategory
            val matchesDate = selectedDateKey == null || tx.dateKey == selectedDateKey

            val indianDate = IndianFormatters.formatIndianDate(tx.dateKey)
            val rupeeStr = IndianFormatters.paiseToPlainRupeeString(tx.amountPaise)
            val formattedRupee = IndianFormatters.formatInr(tx.amountPaise).lowercase()
            val matchesQuery = q.isEmpty() ||
                indianDate.contains(q, ignoreCase = true) ||
                tx.dateKey.contains(q, ignoreCase = true) ||
                rupeeStr.contains(q, ignoreCase = true) ||
                formattedRupee.contains(q, ignoreCase = true) ||
                tx.category.lowercase().contains(q) ||
                tx.note.lowercase().contains(q)

            matchesType && matchesCat && matchesDate && matchesQuery
        }
    }

    val groupedByDate = remember(filteredTransactions) {
        filteredTransactions.groupBy { it.dateKey }.toSortedMap(compareByDescending { it })
    }

    Column(modifier = modifier.fillMaxSize()) {
        // Header & Search Controls
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "लेन-देन इतिहास",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${filteredTransactions.size} रिकॉर्ड",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("तारीख (DD-MM-YYYY), राशि या श्रेणी खोजें...") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Rounded.Clear, contentDescription = "साफ़ करें")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("history_search_input")
            )

            // Type & Date Filters
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = selectedTypeFilter == null,
                    onClick = {
                        selectedTypeFilter = null
                        selectedCategory = null
                    },
                    label = { Text("सभी") }
                )
                FilterChip(
                    selected = selectedTypeFilter == TransactionType.EXPENSE,
                    onClick = {
                        selectedTypeFilter = if (selectedTypeFilter == TransactionType.EXPENSE) null else TransactionType.EXPENSE
                        selectedCategory = null
                    },
                    label = { Text("खर्च") }
                )
                FilterChip(
                    selected = selectedTypeFilter == TransactionType.INCOME,
                    onClick = {
                        selectedTypeFilter = if (selectedTypeFilter == TransactionType.INCOME) null else TransactionType.INCOME
                        selectedCategory = null
                    },
                    label = { Text("आय") }
                )
                OutlinedButton(
                    onClick = { showDatePicker = true },
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CalendarToday,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = selectedDateKey?.let { IndianFormatters.formatIndianDate(it) } ?: "तारीख चुनें",
                        style = MaterialTheme.typography.labelMedium
                    )
                }
                if (selectedDateKey != null) {
                    TextButton(onClick = { selectedDateKey = null }) {
                        Text("तारीख हटाएं")
                    }
                }
            }

            if (availableCategories.isNotEmpty()) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    availableCategories.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = {
                                selectedCategory = if (selectedCategory == cat) null else cat
                            },
                            label = { Text(cat) }
                        )
                    }
                }
            }
        }

        if (groupedByDate.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_empty_ledger),
                    contentDescription = "कोई लेन-देन नहीं",
                    modifier = Modifier
                        .size(170.dp)
                        .clip(RoundedCornerShape(20.dp)),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = if (transactions.isEmpty()) "अभी तक कोई लेन-देन नहीं है" else "खोज से मेल खाने वाला कोई रिकॉर्ड नहीं मिला",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (transactions.isEmpty()) {
                        "नीचे '+' बटन दबाकर अपना दैनिक खर्च या आय जोड़ें।"
                    } else {
                        "कृपया खोज शब्द या फ़िल्टर बदलकर पुनः देखें।"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 92.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                groupedByDate.forEach { (dateKey, dayList) ->
                    val dayIncome = dayList.filter { it.transactionType() == TransactionType.INCOME }.sumOf { it.amountPaise }
                    val dayExpense = dayList.filter { it.transactionType() == TransactionType.EXPENSE }.sumOf { it.amountPaise }

                    item(key = "header_$dateKey") {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 7.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = IndianFormatters.formatIndianDateLabel(dateKey),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    if (dayIncome > 0L) {
                                        Text(
                                            text = "+${IndianFormatters.formatInr(dayIncome)}",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            color = financeColors.income
                                        )
                                    }
                                    if (dayExpense > 0L) {
                                        Text(
                                            text = "-${IndianFormatters.formatInr(dayExpense)}",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            color = financeColors.expense
                                        )
                                    }
                                }
                            }
                        }
                    }

                    items(dayList, key = { it.id }) { tx ->
                        TransactionRowCard(
                            transaction = tx,
                            onEdit = { onEditTransaction(tx) },
                            onDelete = { onDeleteTransaction(tx) }
                        )
                    }
                }
            }
        }
    }

    if (showDatePicker) {
        IndianDatePickerDialog(
            initialDateKey = selectedDateKey ?: IndianFormatters.todayDateKey(),
            onDismiss = { showDatePicker = false },
            onDateSelected = {
                selectedDateKey = it
                showDatePicker = false
            }
        )
    }
}
