package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.CategoryBreakdown
import com.example.data.model.DailyBarPoint
import com.example.data.model.MonthlySummaryRow
import com.example.ui.theme.LocalFinanceColors
import com.example.util.IndianFormatters
import kotlin.math.max

@Composable
fun IncomeExpenseBarChart(
    points: List<DailyBarPoint>,
    modifier: Modifier = Modifier
) {
    val financeColors = LocalFinanceColors.current
    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
    val maxVal = max(
        1L,
        points.maxOfOrNull { max(it.incomePaise, it.expensePaise) } ?: 1L
    )

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            LegendDot(color = financeColors.income, label = "आय")
            Spacer(modifier = Modifier.width(14.dp))
            LegendDot(color = financeColors.expense, label = "खर्च")
        }

        Spacer(modifier = Modifier.height(10.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(148.dp)
        ) {
            val chartHeight = size.height - 8.dp.toPx()
            val slotWidth = size.width / points.size.coerceAtLeast(1)
            val barWidth = (slotWidth * 0.28f).coerceIn(6.dp.toPx(), 16.dp.toPx())
            val gap = 3.dp.toPx()

            // Horizontal baseline & mid guide lines
            for (step in listOf(0.25f, 0.5f, 0.75f, 1f)) {
                val y = chartHeight * (1f - step) + 4.dp.toPx()
                drawLine(
                    color = gridColor,
                    start = Offset(0f, y),
                    end = Offset(size.width, y),
                    strokeWidth = 1.dp.toPx()
                )
            }

            points.forEachIndexed { idx, pt ->
                val centerX = slotWidth * idx + slotWidth / 2f
                val incRatio = (pt.incomePaise.toFloat() / maxVal.toFloat()).coerceIn(0f, 1f)
                val expRatio = (pt.expensePaise.toFloat() / maxVal.toFloat()).coerceIn(0f, 1f)

                val incHeight = (chartHeight * incRatio).coerceAtLeast(if (pt.incomePaise > 0) 4.dp.toPx() else 0f)
                val expHeight = (chartHeight * expRatio).coerceAtLeast(if (pt.expensePaise > 0) 4.dp.toPx() else 0f)

                if (incHeight > 0f) {
                    drawRoundRect(
                        color = financeColors.income,
                        topLeft = Offset(centerX - barWidth - gap / 2f, size.height - incHeight),
                        size = Size(barWidth, incHeight),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                    )
                }
                if (expHeight > 0f) {
                    drawRoundRect(
                        color = financeColors.expense,
                        topLeft = Offset(centerX + gap / 2f, size.height - expHeight),
                        size = Size(barWidth, expHeight),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            points.forEach { pt ->
                Text(
                    text = pt.shortLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun CategoryDonutChart(
    breakdowns: List<CategoryBreakdown>,
    totalExpensePaise: Long,
    modifier: Modifier = Modifier
) {
    val trackColor = MaterialTheme.colorScheme.surfaceVariant
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(132.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(124.dp)) {
                val strokeWidth = 18.dp.toPx()
                val arcSize = Size(size.width - strokeWidth, size.height - strokeWidth)
                val topLeft = Offset(strokeWidth / 2f, strokeWidth / 2f)

                if (breakdowns.isEmpty()) {
                    drawArc(
                        color = trackColor,
                        startAngle = 0f,
                        sweepAngle = 360f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidth)
                    )
                } else {
                    var startAngle = -90f
                    breakdowns.forEach { item ->
                        val sweep = (item.percentage / 100f) * 360f
                        val gap = if (breakdowns.size > 1) 2.5f else 0f
                        drawArc(
                            color = item.color,
                            startAngle = startAngle,
                            sweepAngle = (sweep - gap).coerceAtLeast(2f),
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                        )
                        startAngle += sweep
                    }
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "कुल खर्च",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = IndianFormatters.formatCompactInr(totalExpensePaise),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            breakdowns.take(5).forEach { item ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(item.color)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = item.category,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "${item.percentage.toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(end = 6.dp)
                    )
                    Text(
                        text = IndianFormatters.formatCompactInr(item.amountPaise),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun MonthlyTrendChart(
    months: List<MonthlySummaryRow>,
    modifier: Modifier = Modifier
) {
    val displayMonths = months.take(6).reversed()
    val financeColors = LocalFinanceColors.current
    val maxVal = max(1L, displayMonths.maxOfOrNull { max(it.incomePaise, it.expensePaise) } ?: 1L)

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.End)
        ) {
            LegendDot(color = financeColors.income, label = "आय")
            LegendDot(color = financeColors.expense, label = "खर्च")
            LegendDot(color = financeColors.savings, label = "बचत")
        }
        Spacer(modifier = Modifier.height(10.dp))
        displayMonths.forEach { row ->
            Column(modifier = Modifier.padding(vertical = 5.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = row.monthTitle,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "बचत: ${IndianFormatters.formatInr(row.savingsPaise)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (row.savingsPaise >= 0) financeColors.savings else financeColors.expense,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                val incFraction = (row.incomePaise.toFloat() / maxVal.toFloat()).coerceIn(0f, 1f)
                val expFraction = (row.expensePaise.toFloat() / maxVal.toFloat()).coerceIn(0f, 1f)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(incFraction)
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(financeColors.income)
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(expFraction)
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(financeColors.expense)
                    )
                }
            }
        }
    }
}

@Composable
private fun LegendDot(color: androidx.compose.ui.graphics.Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
