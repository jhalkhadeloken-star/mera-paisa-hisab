package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class FinanceSemanticColors(
    val income: Color,
    val incomeContainer: Color,
    val onIncomeContainer: Color,
    val expense: Color,
    val expenseContainer: Color,
    val onExpenseContainer: Color,
    val savings: Color,
    val savingsContainer: Color,
    val onSavingsContainer: Color,
    val udhar: Color,
    val udharContainer: Color,
    val onUdharContainer: Color,
    val cardBackground: Color
)

private val LightFinanceColors = FinanceSemanticColors(
    income = IncomeGreenLight,
    incomeContainer = IncomeGreenContainerLight,
    onIncomeContainer = OnIncomeGreenContainerLight,
    expense = ExpenseRedLight,
    expenseContainer = ExpenseRedContainerLight,
    onExpenseContainer = OnExpenseRedContainerLight,
    savings = SavingsBlueLight,
    savingsContainer = SavingsBlueContainerLight,
    onSavingsContainer = OnSavingsBlueContainerLight,
    udhar = AmberSecondary,
    udharContainer = AmberContainerLight,
    onUdharContainer = OnAmberContainerLight,
    cardBackground = SurfaceCardLight
)

private val DarkFinanceColors = FinanceSemanticColors(
    income = IncomeGreenDark,
    incomeContainer = IncomeGreenContainerDark,
    onIncomeContainer = OnIncomeGreenContainerDark,
    expense = ExpenseRedDark,
    expenseContainer = ExpenseRedContainerDark,
    onExpenseContainer = OnExpenseRedContainerDark,
    savings = SavingsBlueDark,
    savingsContainer = SavingsBlueContainerDark,
    onSavingsContainer = OnSavingsBlueContainerDark,
    udhar = AmberSecondaryDark,
    udharContainer = AmberContainerDark,
    onUdharContainer = OnAmberContainerDark,
    cardBackground = SurfaceCardDark
)

val LocalFinanceColors = staticCompositionLocalOf { LightFinanceColors }

private val LightColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.White,
    primaryContainer = EmeraldContainerLight,
    onPrimaryContainer = OnEmeraldContainerLight,
    secondary = AmberSecondary,
    onSecondary = Color.White,
    secondaryContainer = AmberContainerLight,
    onSecondaryContainer = OnAmberContainerLight,
    tertiary = SavingsBlueLight,
    onTertiary = Color.White,
    tertiaryContainer = SavingsBlueContainerLight,
    onTertiaryContainer = OnSavingsBlueContainerLight,
    background = SurfaceBgLight,
    onBackground = OnSurfaceLight,
    surface = SurfaceCardLight,
    onSurface = OnSurfaceLight,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = OnSurfaceVariantLight,
    outline = OutlineLight,
    error = ExpenseRedLight,
    onError = Color.White,
    errorContainer = ExpenseRedContainerLight,
    onErrorContainer = OnExpenseRedContainerLight
)

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldPrimaryDark,
    onPrimary = Color(0xFF042F25),
    primaryContainer = EmeraldContainerDark,
    onPrimaryContainer = OnEmeraldContainerDark,
    secondary = AmberSecondaryDark,
    onSecondary = Color(0xFF422006),
    secondaryContainer = AmberContainerDark,
    onSecondaryContainer = OnAmberContainerDark,
    tertiary = SavingsBlueDark,
    onTertiary = Color(0xFF0B1F4D),
    tertiaryContainer = SavingsBlueContainerDark,
    onTertiaryContainer = OnSavingsBlueContainerDark,
    background = SurfaceBgDark,
    onBackground = OnSurfaceDark,
    surface = SurfaceCardDark,
    onSurface = OnSurfaceDark,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = OnSurfaceVariantDark,
    outline = OutlineDark,
    error = ExpenseRedDark,
    onError = Color(0xFF450A0A),
    errorContainer = ExpenseRedContainerDark,
    onErrorContainer = OnExpenseRedContainerDark
)

val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MeraPaisaHisabTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val financeColors = if (darkTheme) DarkFinanceColors else LightFinanceColors

    CompositionLocalProvider(LocalFinanceColors provides financeColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AppTypography,
            shapes = AppShapes,
            content = content
        )
    }
}
