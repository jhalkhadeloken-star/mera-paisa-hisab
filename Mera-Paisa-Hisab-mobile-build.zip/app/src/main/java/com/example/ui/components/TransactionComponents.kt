package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CalendarToday
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.HelpOutline
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.ai.SmartParseResult
import com.example.data.model.EntrySource
import com.example.data.model.FinanceCategories
import com.example.data.model.LedgerTransaction
import com.example.data.model.TransactionType
import com.example.data.model.UdharEntryType
import com.example.ui.theme.LocalFinanceColors
import com.example.util.IndianFormatters
import java.util.UUID

@Composable
fun TransactionRowCard(
    transaction: LedgerTransaction,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val financeColors = LocalFinanceColors.current
    val txType = transaction.transactionType()
    val isIncome = txType == TransactionType.INCOME
    val catInfo = FinanceCategories.infoFor(transaction.category, txType)
    val amountColor = if (isIncome) financeColors.income else financeColors.expense

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onEdit),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(catInfo.color.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = catInfo.icon,
                    contentDescription = transaction.category,
                    tint = catInfo.color,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = transaction.category,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (transaction.source == EntrySource.SMART_TEXT.name) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "स्मार्ट",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
                if (transaction.note.isNotBlank()) {
                    Text(
                        text = transaction.note,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    text = IndianFormatters.formatIndianDate(transaction.dateKey),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = IndianFormatters.formatInr(
                        paise = if (isIncome) transaction.amountPaise else -transaction.amountPaise,
                        showPlus = isIncome,
                        showSignIfNegative = true
                    ),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = amountColor
                )
                Row {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier
                            .size(36.dp)
                            .minimumInteractiveComponentSize()
                            .testTag("edit_tx_${transaction.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Edit,
                            contentDescription = "संपादित करें",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(36.dp)
                            .minimumInteractiveComponentSize()
                            .testTag("delete_tx_${transaction.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteOutline,
                            contentDescription = "हटाएं",
                            tint = financeColors.expense,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddEditTransactionSheet(
    initialTransaction: LedgerTransaction?,
    initialType: TransactionType = TransactionType.EXPENSE,
    existingTransactions: List<LedgerTransaction>,
    isSaving: Boolean,
    onDismiss: () -> Unit,
    onSave: (
        transactionId: String,
        isEdit: Boolean,
        type: TransactionType,
        amountPaise: Long,
        category: String,
        note: String,
        dateKey: String,
        source: EntrySource
    ) -> Unit
) {
    val isEdit = initialTransaction != null
    val stableDraftId = remember(initialTransaction?.id) {
        initialTransaction?.id?.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
    }
    var txType by remember(initialTransaction, initialType) {
        mutableStateOf(initialTransaction?.transactionType() ?: initialType)
    }
    var amountText by remember(initialTransaction) {
        mutableStateOf(
            initialTransaction?.let { IndianFormatters.paiseToPlainRupeeString(it.amountPaise) } ?: ""
        )
    }
    var selectedCategory by remember(initialTransaction, txType) {
        mutableStateOf(
            initialTransaction?.category ?: if (txType == TransactionType.INCOME) "वेतन" else "भोजन"
        )
    }
    var note by remember(initialTransaction) {
        mutableStateOf(initialTransaction?.note ?: "")
    }
    var dateKey by remember(initialTransaction) {
        mutableStateOf(initialTransaction?.dateKey ?: IndianFormatters.todayDateKey())
    }
    var showDatePicker by remember { mutableStateOf(false) }
    var validationError by remember { mutableStateOf<String?>(null) }
    var duplicateOverrideConfirmed by remember { mutableStateOf(false) }

    val financeColors = LocalFinanceColors.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val categories = if (txType == TransactionType.INCOME) {
        FinanceCategories.incomeCategories
    } else {
        FinanceCategories.expenseCategories
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isEdit) "लेन-देन संपादित करें" else "नया आय / खर्च जोड़ें",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "बंद करें")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = txType == TransactionType.EXPENSE,
                    onClick = {
                        txType = TransactionType.EXPENSE
                        if (FinanceCategories.expenseCategories.none { it.name == selectedCategory }) {
                            selectedCategory = "भोजन"
                        }
                        duplicateOverrideConfirmed = false
                    },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                    colors = SegmentedButtonDefaults.colors(
                        activeContainerColor = financeColors.expenseContainer,
                        activeContentColor = financeColors.onExpenseContainer
                    ),
                    modifier = Modifier.testTag("type_expense_tab")
                ) {
                    Text("खर्च (Expense)", fontWeight = FontWeight.SemiBold)
                }
                SegmentedButton(
                    selected = txType == TransactionType.INCOME,
                    onClick = {
                        txType = TransactionType.INCOME
                        if (FinanceCategories.incomeCategories.none { it.name == selectedCategory }) {
                            selectedCategory = "वेतन"
                        }
                        duplicateOverrideConfirmed = false
                    },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                    colors = SegmentedButtonDefaults.colors(
                        activeContainerColor = financeColors.incomeContainer,
                        activeContentColor = financeColors.onIncomeContainer
                    ),
                    modifier = Modifier.testTag("type_income_tab")
                ) {
                    Text("आय (Income)", fontWeight = FontWeight.SemiBold)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = amountText,
                onValueChange = {
                    amountText = it
                    validationError = null
                    duplicateOverrideConfirmed = false
                },
                label = { Text("राशि (₹ में) *") },
                placeholder = { Text("उदा. 250") },
                prefix = { Text("₹ ", fontWeight = FontWeight.Bold) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tx_amount_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = { showDatePicker = true },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("tx_date_picker_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.CalendarToday,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "तारीख: ${IndianFormatters.formatIndianDateLabel(dateKey)}",
                    style = MaterialTheme.typography.bodyLarge
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "श्रेणी चुनें",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    val selected = selectedCategory == cat.name
                    FilterChip(
                        selected = selected,
                        onClick = {
                            selectedCategory = cat.name
                            duplicateOverrideConfirmed = false
                        },
                        label = { Text(cat.name) },
                        leadingIcon = {
                            Icon(
                                imageVector = cat.icon,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = cat.color.copy(alpha = 0.18f),
                            selectedLabelColor = MaterialTheme.colorScheme.onSurface
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = note,
                onValueChange = {
                    if (it.length <= 250) note = it
                    duplicateOverrideConfirmed = false
                },
                label = { Text("विवरण / नोट (वैकल्पिक)") },
                placeholder = { Text("जैसे: चाय-नाश्ता, सब्ज़ी, पेट्रोल...") },
                maxLines = 2,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tx_note_input")
            )

            val parsedPaise = IndianFormatters.parseRupeesToPaise(amountText)
            val potentialDup = parsedPaise != null && existingTransactions.any { tx ->
                tx.id != (if (isEdit) stableDraftId else null) &&
                    tx.transactionType() == txType &&
                    tx.amountPaise == parsedPaise &&
                    tx.dateKey == dateKey &&
                    tx.category == selectedCategory &&
                    tx.note.trim().equals(note.trim(), ignoreCase = true)
            }

            if (potentialDup && !duplicateOverrideConfirmed) {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = financeColors.udharContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.WarningAmber,
                            contentDescription = null,
                            tint = financeColors.udhar
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "डुप्लिकेट लेन-देन की चेतावनी",
                                style = MaterialTheme.typography.labelLarge,
                                color = financeColors.onUdharContainer
                            )
                            Text(
                                text = "इसी तारीख, राशि और श्रेणी की एक एंट्री पहले से मौजूद है। क्या आप फिर भी सहेजना चाहते हैं?",
                                style = MaterialTheme.typography.bodySmall,
                                color = financeColors.onUdharContainer
                            )
                        }
                    }
                }
            }

            if (validationError != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = validationError.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = financeColors.expense
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Button(
                onClick = {
                    val amountPaise = IndianFormatters.parseRupeesToPaise(amountText)
                    if (amountPaise == null || amountPaise <= 0L) {
                        validationError = "कृपया ₹0 से अधिक की सही राशि दर्ज करें।"
                        return@Button
                    }
                    if (potentialDup && !duplicateOverrideConfirmed) {
                        duplicateOverrideConfirmed = true
                        return@Button
                    }
                    onSave(
                        stableDraftId,
                        isEdit,
                        txType,
                        amountPaise,
                        selectedCategory,
                        note.trim(),
                        dateKey,
                        if (isEdit) {
                            enumValues<EntrySource>().firstOrNull {
                                it.name == initialTransaction?.source
                            } ?: EntrySource.MANUAL
                        } else {
                            EntrySource.MANUAL
                        }
                    )
                },
                enabled = !isSaving,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (txType == TransactionType.INCOME) {
                        financeColors.income
                    } else {
                        MaterialTheme.colorScheme.primary
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_tx_button")
            ) {
                Icon(Icons.Rounded.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = when {
                        isSaving -> "सहेजा जा रहा है..."
                        potentialDup && !duplicateOverrideConfirmed -> "डुप्लिकेट जांचें — दोबारा दबाकर सहेजें"
                        isEdit -> "परिवर्तन सहेजें"
                        else -> "लेन-देन सहेजें"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }

    if (showDatePicker) {
        IndianDatePickerDialog(
            initialDateKey = dateKey,
            onDismiss = { showDatePicker = false },
            onDateSelected = {
                dateKey = it
                showDatePicker = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartParseConfirmationSheet(
    parsed: SmartParseResult,
    isSaving: Boolean,
    onDismiss: () -> Unit,
    onConfirmTransaction: (
        txId: String,
        type: TransactionType,
        amountPaise: Long,
        category: String,
        note: String,
        dateKey: String
    ) -> Unit,
    onConfirmUdhar: (
        entryId: String,
        personName: String,
        entryType: UdharEntryType,
        amountPaise: Long,
        dateKey: String,
        note: String
    ) -> Unit
) {
    val financeColors = LocalFinanceColors.current
    val draftId = remember(parsed) { UUID.randomUUID().toString() }
    var intentKind by remember(parsed) { mutableStateOf(parsed.intentKind) }
    var amountText by remember(parsed) {
        mutableStateOf(
            parsed.amountPaise?.let { IndianFormatters.paiseToPlainRupeeString(it) } ?: ""
        )
    }
    var category by remember(parsed) { mutableStateOf(parsed.category) }
    var note by remember(parsed) { mutableStateOf(parsed.note) }
    var personName by remember(parsed) { mutableStateOf(parsed.personName) }
    var dateKey by remember(parsed) { mutableStateOf(parsed.dateKey) }
    var showDatePicker by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val isUdhar = intentKind.startsWith("UDHAR")
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (parsed.needsConfirmation) "पुष्टि आवश्यक है" else "स्मार्ट एंट्री तैयार है",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (parsed.usedAi) "Gemini AI" else "ऑफ़लाइन पार्सर",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            if (parsed.needsConfirmation && parsed.clarificationQuestion.isNotBlank()) {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = financeColors.udharContainer),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.HelpOutline,
                            contentDescription = null,
                            tint = financeColors.udhar
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = parsed.clarificationQuestion,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = financeColors.onUdharContainer
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "लेन-देन का प्रकार",
                style = MaterialTheme.typography.labelLarge
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val options = listOf(
                    "EXPENSE" to "खर्च",
                    "INCOME" to "आय",
                    "UDHAR_GIVEN" to "उधार दिया",
                    "UDHAR_BORROWED" to "उधार लिया",
                    "UDHAR_REPAYMENT_RECEIVED" to "वापस मिला",
                    "UDHAR_REPAYMENT_PAID" to "वापस किया"
                )
                options.forEach { (key, label) ->
                    FilterChip(
                        selected = intentKind == key,
                        onClick = {
                            intentKind = key
                            if (key == "INCOME" && FinanceCategories.incomeCategories.none { it.name == category }) {
                                category = "वेतन"
                            } else if (key == "EXPENSE" && FinanceCategories.expenseCategories.none { it.name == category }) {
                                category = "अन्य"
                            }
                        },
                        label = { Text(label) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = amountText,
                onValueChange = {
                    amountText = it
                    errorMsg = null
                },
                label = { Text("राशि (₹) *") },
                prefix = { Text("₹ ", fontWeight = FontWeight.Bold) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            if (isUdhar) {
                OutlinedTextField(
                    value = personName,
                    onValueChange = {
                        personName = it
                        errorMsg = null
                    },
                    label = { Text("व्यक्ति का नाम *") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))
            } else {
                Text(
                    text = "श्रेणी",
                    style = MaterialTheme.typography.labelLarge
                )
                Spacer(modifier = Modifier.height(6.dp))
                val cats = if (intentKind == "INCOME") {
                    FinanceCategories.incomeCategories
                } else {
                    FinanceCategories.expenseCategories
                }
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    cats.forEach { cat ->
                        FilterChip(
                            selected = category == cat.name,
                            onClick = { category = cat.name },
                            label = { Text(cat.name) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            OutlinedButton(
                onClick = { showDatePicker = true },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.CalendarToday, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("तारीख: ${IndianFormatters.formatIndianDateLabel(dateKey)}")
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = note,
                onValueChange = { if (it.length <= 250) note = it },
                label = { Text("विवरण") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            if (errorMsg != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorMsg.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = financeColors.expense
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("रद्द करें")
                }
                Button(
                    onClick = {
                        val paise = IndianFormatters.parseRupeesToPaise(amountText)
                        if (paise == null || paise <= 0L) {
                            errorMsg = "कृपया सही राशि (₹) दर्ज करें।"
                            return@Button
                        }
                        if (isUdhar) {
                            if (personName.trim().isEmpty()) {
                                errorMsg = "कृपया व्यक्ति का नाम दर्ज करें।"
                                return@Button
                            }
                            val udharType = when (intentKind) {
                                "UDHAR_BORROWED" -> UdharEntryType.BORROWED
                                "UDHAR_REPAYMENT_RECEIVED" -> UdharEntryType.REPAYMENT_RECEIVED
                                "UDHAR_REPAYMENT_PAID" -> UdharEntryType.REPAYMENT_PAID
                                else -> UdharEntryType.GIVEN
                            }
                            onConfirmUdhar(draftId, personName.trim(), udharType, paise, dateKey, note.trim())
                        } else {
                            val txType = if (intentKind == "INCOME") TransactionType.INCOME else TransactionType.EXPENSE
                            onConfirmTransaction(draftId, txType, paise, category, note.trim(), dateKey)
                        }
                    },
                    enabled = !isSaving,
                    modifier = Modifier
                        .weight(1.4f)
                        .height(50.dp)
                        .testTag("confirm_smart_save_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Rounded.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isSaving) "सहेज रहा है..." else "पुष्टि करें व सहेजें")
                }
            }
        }
    }

    if (showDatePicker) {
        IndianDatePickerDialog(
            initialDateKey = dateKey,
            onDismiss = { showDatePicker = false },
            onDateSelected = {
                dateKey = it
                showDatePicker = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IndianDatePickerDialog(
    initialDateKey: String,
    onDismiss: () -> Unit,
    onDateSelected: (String) -> Unit
) {
    val initialMillis = remember(initialDateKey) {
        IndianFormatters.dateKeyToMillis(initialDateKey) ?: System.currentTimeMillis()
    }
    val pickerState = rememberDatePickerState(initialSelectedDateMillis = initialMillis)
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    val millis = pickerState.selectedDateMillis ?: initialMillis
                    onDateSelected(IndianFormatters.millisToDateKey(millis))
                }
            ) {
                Text("चुनें")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("रद्द करें")
            }
        }
    ) {
        DatePicker(state = pickerState)
    }
}

@Composable
fun DeleteConfirmDialog(
    title: String,
    message: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    val financeColors = LocalFinanceColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(message) },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = financeColors.expense)
            ) {
                Text("हटाएं")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("रद्द करें")
            }
        }
    )
}
