package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarToday
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Handshake
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.PersonUdharSummary
import com.example.data.model.UdharEntry
import com.example.data.model.UdharEntryType
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.IndianDatePickerDialog
import com.example.ui.theme.LocalFinanceColors
import com.example.util.IndianFormatters
import java.util.UUID
import kotlin.math.abs

private enum class UdharFilter(val label: String) {
    ALL("सभी"),
    RECEIVABLE("लेना है"),
    PAYABLE("देना है"),
    SETTLED("बराबर")
}

@Composable
fun UdharScreen(
    summaries: List<PersonUdharSummary>,
    totalReceivablePaise: Long,
    totalPayablePaise: Long,
    isSaving: Boolean,
    onSaveUdharEntry: (
        entryId: String,
        isEdit: Boolean,
        personName: String,
        phone: String?,
        entryType: UdharEntryType,
        amountPaise: Long,
        dateKey: String,
        dueDateKey: String?,
        note: String,
        onDone: () -> Unit
    ) -> Unit,
    onDeleteUdharEntry: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val financeColors = LocalFinanceColors.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(UdharFilter.ALL) }
    var selectedPersonKey by remember { mutableStateOf<String?>(null) }

    var showAddEditSheet by remember { mutableStateOf(false) }
    var editingEntry by remember { mutableStateOf<UdharEntry?>(null) }
    var prefillPersonName by remember { mutableStateOf("") }
    var prefillPhone by remember { mutableStateOf("") }
    var prefillType by remember { mutableStateOf(UdharEntryType.GIVEN) }
    var deletingEntry by remember { mutableStateOf<UdharEntry?>(null) }

    val filteredSummaries = remember(summaries, searchQuery, selectedFilter) {
        val q = searchQuery.trim().lowercase()
        summaries.filter { p ->
            val matchesQuery = q.isEmpty() ||
                p.personName.lowercase().contains(q) ||
                (p.phone?.contains(q) == true)
            val matchesFilter = when (selectedFilter) {
                UdharFilter.ALL -> true
                UdharFilter.RECEIVABLE -> p.netBalancePaise > 0L
                UdharFilter.PAYABLE -> p.netBalancePaise < 0L
                UdharFilter.SETTLED -> p.netBalancePaise == 0L
            }
            matchesQuery && matchesFilter
        }
    }

    val selectedPerson = remember(summaries, selectedPersonKey) {
        selectedPersonKey?.let { key -> summaries.firstOrNull { it.personKey == key } }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "उधार खाता",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = {
                        editingEntry = null
                        prefillPersonName = ""
                        prefillPhone = ""
                        prefillType = UdharEntryType.GIVEN
                        showAddEditSheet = true
                    },
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("add_udhar_button")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("नई एंट्री")
                }
            }

            // Summary Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = financeColors.incomeContainer,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "कुल लेना है",
                            style = MaterialTheme.typography.labelMedium,
                            color = financeColors.onIncomeContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = IndianFormatters.formatInr(totalReceivablePaise),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = financeColors.income
                        )
                    }
                }
                Surface(
                    color = financeColors.expenseContainer,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "कुल देना है",
                            style = MaterialTheme.typography.labelMedium,
                            color = financeColors.onExpenseContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = IndianFormatters.formatInr(totalPayablePaise),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = financeColors.expense
                        )
                    }
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("व्यक्ति का नाम या फ़ोन नंबर खोजें...") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("udhar_search_input")
            )

            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                UdharFilter.entries.forEach { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter.label) }
                    )
                }
            }
        }

        if (filteredSummaries.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Handshake,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = if (summaries.isEmpty()) "अभी कोई उधार रिकॉर्ड नहीं है" else "कोई व्यक्ति नहीं मिला",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "किसी को पैसे दिए हों, किसी से उधार लिया हो या वापसी दर्ज करनी हो तो 'नई एंट्री' दबाएं।",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 92.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredSummaries, key = { it.personKey }) { person ->
                    PersonUdharCard(
                        person = person,
                        onClick = { selectedPersonKey = person.personKey },
                        onQuickRepayment = {
                            editingEntry = null
                            prefillPersonName = person.personName
                            prefillPhone = person.phone.orEmpty()
                            prefillType = if (person.netBalancePaise >= 0L) {
                                UdharEntryType.REPAYMENT_RECEIVED
                            } else {
                                UdharEntryType.REPAYMENT_PAID
                            }
                            showAddEditSheet = true
                        }
                    )
                }
            }
        }
    }

    if (selectedPerson != null) {
        PersonUdharDetailSheet(
            person = selectedPerson,
            onDismiss = { selectedPersonKey = null },
            onAddForPerson = { defaultType ->
                editingEntry = null
                prefillPersonName = selectedPerson.personName
                prefillPhone = selectedPerson.phone.orEmpty()
                prefillType = defaultType
                showAddEditSheet = true
            },
            onEditEntry = { entry ->
                editingEntry = entry
                showAddEditSheet = true
            },
            onDeleteEntry = { entry ->
                deletingEntry = entry
            }
        )
    }

    if (showAddEditSheet) {
        AddEditUdharSheet(
            initialEntry = editingEntry,
            prefillPersonName = prefillPersonName,
            prefillPhone = prefillPhone,
            prefillType = prefillType,
            existingPersonNames = summaries.map { it.personName },
            isSaving = isSaving,
            onDismiss = {
                showAddEditSheet = false
                editingEntry = null
            },
            onSave = { id, isEdit, name, phone, type, amountPaise, dateKey, dueDateKey, note ->
                onSaveUdharEntry(
                    id, isEdit, name, phone, type, amountPaise, dateKey, dueDateKey, note
                ) {
                    showAddEditSheet = false
                    editingEntry = null
                }
            }
        )
    }

    deletingEntry?.let { entry ->
        DeleteConfirmDialog(
            title = "उधार एंट्री हटाएं?",
            message = "${entry.personName} की ${IndianFormatters.formatInr(entry.amountPaise)} (${entry.udharType().hindiLabel}) एंट्री स्थायी रूप से हटा दी जाएगी।",
            onDismiss = { deletingEntry = null },
            onConfirm = {
                onDeleteUdharEntry(entry.id)
                deletingEntry = null
            }
        )
    }
}

@Composable
private fun PersonUdharCard(
    person: PersonUdharSummary,
    onClick: () -> Unit,
    onQuickRepayment: () -> Unit
) {
    val financeColors = LocalFinanceColors.current
    val statusText = when {
        person.netBalancePaise > 0L -> "लेना है"
        person.netBalancePaise < 0L -> "देना है"
        else -> "हिसाब बराबर"
    }
    val statusColor = when {
        person.netBalancePaise > 0L -> financeColors.income
        person.netBalancePaise < 0L -> financeColors.expense
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    val statusBg = when {
        person.netBalancePaise > 0L -> financeColors.incomeContainer
        person.netBalancePaise < 0L -> financeColors.expenseContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = person.personName.take(1).uppercase(),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = person.personName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${person.entries.size} लेन-देन • अंतिम: ${IndianFormatters.formatIndianDate(person.latestDateKey)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = IndianFormatters.formatInr(abs(person.netBalancePaise)),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = statusColor
                    )
                    Surface(
                        color = statusBg,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = statusColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            if (person.netBalancePaise != 0L) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = onQuickRepayment,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Payments,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (person.netBalancePaise > 0L) "वापसी मिली दर्ज करें" else "भुगतान किया दर्ज करें",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PersonUdharDetailSheet(
    person: PersonUdharSummary,
    onDismiss: () -> Unit,
    onAddForPerson: (UdharEntryType) -> Unit,
    onEditEntry: (UdharEntry) -> Unit,
    onDeleteEntry: (UdharEntry) -> Unit
) {
    BackHandler { onDismiss() }
    val financeColors = LocalFinanceColors.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = person.personName,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    if (!person.phone.isNullOrBlank()) {
                        Text(
                            text = "फ़ोन: ${person.phone}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "बंद करें")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            val netLabel = when {
                person.netBalancePaise > 0L -> "${IndianFormatters.formatInr(person.netBalancePaise)} लेना है"
                person.netBalancePaise < 0L -> "${IndianFormatters.formatInr(-person.netBalancePaise)} देना है"
                else -> "हिसाब पूरा बराबर है"
            }
            Surface(
                color = when {
                    person.netBalancePaise > 0L -> financeColors.incomeContainer
                    person.netBalancePaise < 0L -> financeColors.expenseContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "शुद्ध स्थिति: $netLabel",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = when {
                        person.netBalancePaise > 0L -> financeColors.income
                        person.netBalancePaise < 0L -> financeColors.expense
                        else -> MaterialTheme.colorScheme.onSurface
                    },
                    modifier = Modifier.padding(14.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onAddForPerson(UdharEntryType.GIVEN) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("उधार दिया", style = MaterialTheme.typography.labelMedium)
                }
                OutlinedButton(
                    onClick = {
                        onAddForPerson(
                            if (person.netBalancePaise >= 0L) UdharEntryType.REPAYMENT_RECEIVED
                            else UdharEntryType.REPAYMENT_PAID
                        )
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("वापसी दर्ज", style = MaterialTheme.typography.labelMedium)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "लेन-देन विवरण",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                person.entries.forEach { entry ->
                    val type = entry.udharType()
                    val isPositiveForMe = type == UdharEntryType.GIVEN || type == UdharEntryType.REPAYMENT_PAID
                    val color = if (type == UdharEntryType.REPAYMENT_RECEIVED || type == UdharEntryType.GIVEN) {
                        financeColors.income
                    } else {
                        financeColors.expense
                    }
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = type.hindiLabel,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = color
                                )
                                Text(
                                    text = IndianFormatters.formatIndianDate(entry.dateKey) +
                                        (entry.dueDateKey?.let { " • देय: ${IndianFormatters.formatIndianDate(it)}" } ?: ""),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (entry.note.isNotBlank()) {
                                    Text(
                                        text = entry.note,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                            Text(
                                text = IndianFormatters.formatInr(entry.amountPaise),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isPositiveForMe) financeColors.savings else financeColors.udhar
                            )
                            IconButton(
                                onClick = { onEditEntry(entry) },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Rounded.Edit, contentDescription = "संपादित करें", modifier = Modifier.size(18.dp))
                            }
                            IconButton(
                                onClick = { onDeleteEntry(entry) },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(
                                    Icons.Rounded.DeleteOutline,
                                    contentDescription = "हटाएं",
                                    tint = financeColors.expense,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddEditUdharSheet(
    initialEntry: UdharEntry?,
    prefillPersonName: String,
    prefillPhone: String,
    prefillType: UdharEntryType,
    existingPersonNames: List<String>,
    isSaving: Boolean,
    onDismiss: () -> Unit,
    onSave: (
        entryId: String,
        isEdit: Boolean,
        personName: String,
        phone: String?,
        entryType: UdharEntryType,
        amountPaise: Long,
        dateKey: String,
        dueDateKey: String?,
        note: String
    ) -> Unit
) {
    val isEdit = initialEntry != null
    val stableId = remember(initialEntry?.id) {
        initialEntry?.id?.takeIf { it.isNotBlank() } ?: UUID.randomUUID().toString()
    }
    var personName by remember(initialEntry, prefillPersonName) {
        mutableStateOf(initialEntry?.personName ?: prefillPersonName)
    }
    var phone by remember(initialEntry, prefillPhone) {
        mutableStateOf(initialEntry?.phone ?: prefillPhone)
    }
    var entryType by remember(initialEntry, prefillType) {
        mutableStateOf(initialEntry?.udharType() ?: prefillType)
    }
    var amountText by remember(initialEntry) {
        mutableStateOf(
            initialEntry?.let { IndianFormatters.paiseToPlainRupeeString(it.amountPaise) } ?: ""
        )
    }
    var dateKey by remember(initialEntry) {
        mutableStateOf(initialEntry?.dateKey ?: IndianFormatters.todayDateKey())
    }
    var dueDateKey by remember(initialEntry) {
        mutableStateOf(initialEntry?.dueDateKey)
    }
    var note by remember(initialEntry) {
        mutableStateOf(initialEntry?.note ?: "")
    }
    var showDatePicker by remember { mutableStateOf(false) }
    var showDueDatePicker by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val financeColors = LocalFinanceColors.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isEdit) "उधार एंट्री संपादित करें" else "उधार / वापसी दर्ज करें",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "बंद करें")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "प्रकार चुनें",
                style = MaterialTheme.typography.labelLarge
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                UdharEntryType.entries.forEach { t ->
                    FilterChip(
                        selected = entryType == t,
                        onClick = { entryType = t },
                        label = { Text(t.hindiLabel) }
                    )
                }
            }
            Text(
                text = entryType.shortHint,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = personName,
                onValueChange = {
                    if (it.length <= 80) personName = it
                    errorMsg = null
                },
                label = { Text("व्यक्ति का नाम *") },
                leadingIcon = { Icon(Icons.Rounded.Person, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("udhar_person_input")
            )

            if (existingPersonNames.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    existingPersonNames.take(8).forEach { name ->
                        AssistChip(
                            onClick = { personName = name },
                            label = { Text(name, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = amountText,
                onValueChange = {
                    amountText = it
                    errorMsg = null
                },
                label = { Text("राशि (₹ में) *") },
                prefix = { Text("₹ ", fontWeight = FontWeight.Bold) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("udhar_amount_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = phone,
                onValueChange = { if (it.length <= 20) phone = it },
                label = { Text("फ़ोन नंबर (वैकल्पिक)") },
                leadingIcon = { Icon(Icons.Rounded.Phone, contentDescription = null) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { showDatePicker = true },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(IndianFormatters.formatIndianDate(dateKey), style = MaterialTheme.typography.labelMedium)
                }
                OutlinedButton(
                    onClick = { showDueDatePicker = true },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = dueDateKey?.let { "देय: ${IndianFormatters.formatIndianDate(it)}" } ?: "देय तारीख (वैकल्पिक)",
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = note,
                onValueChange = { if (it.length <= 250) note = it },
                label = { Text("नोट / कारण (वैकल्पिक)") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            if (errorMsg != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorMsg.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = financeColors.expense
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    val cleanName = personName.trim()
                    if (cleanName.isEmpty()) {
                        errorMsg = "कृपया व्यक्ति का नाम दर्ज करें।"
                        return@Button
                    }
                    val paise = IndianFormatters.parseRupeesToPaise(amountText)
                    if (paise == null || paise <= 0L) {
                        errorMsg = "कृपया ₹0 से अधिक की सही राशि दर्ज करें।"
                        return@Button
                    }
                    onSave(
                        stableId,
                        isEdit,
                        cleanName,
                        phone.trim().takeIf { it.isNotEmpty() },
                        entryType,
                        paise,
                        dateKey,
                        dueDateKey,
                        note.trim()
                    )
                },
                enabled = !isSaving,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_udhar_button")
            ) {
                Icon(Icons.Rounded.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isSaving) "सहेज रहा है..." else if (isEdit) "अपडेट करें" else "उधार सहेजें",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }

    if (showDatePicker) {
        IndianDatePickerDialog(
            initialDateKey = dateKey,
            onDismiss = { showDatePicker = false },
            onDateSelected = {
                dateKey = it
                showDatePicker = false
            }
        )
    }

    if (showDueDatePicker) {
        IndianDatePickerDialog(
            initialDateKey = dueDateKey ?: IndianFormatters.todayDateKey(),
            onDismiss = { showDueDatePicker = false },
            onDateSelected = {
                dueDateKey = it
                showDueDatePicker = false
            }
        )
    }
}
