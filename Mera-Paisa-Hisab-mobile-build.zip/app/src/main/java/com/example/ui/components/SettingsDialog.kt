package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.InstallMobile
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.OfflinePin
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.LedgerTransaction
import com.example.data.model.UdharEntry
import com.example.data.model.UserProfile
import com.example.ui.theme.LocalFinanceColors
import com.example.util.IndianFormatters
import com.example.util.ReportExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsBottomSheet(
    profile: UserProfile?,
    transactions: List<LedgerTransaction>,
    udharEntries: List<UdharEntry>,
    isSaving: Boolean,
    onDismiss: () -> Unit,
    onSaveSettings: (displayName: String, openingBalancePaise: Long, monthlyBudgetPaise: Long) -> Unit,
    onOpenApkDownload: () -> Unit,
    onShowMessage: (String) -> Unit
) {
    BackHandler { onDismiss() }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val financeColors = LocalFinanceColors.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var displayName by remember(profile) {
        mutableStateOf(profile?.displayName?.takeIf { it.isNotBlank() } ?: "मेरा खाता")
    }
    var openingBalanceText by remember(profile) {
        mutableStateOf(
            profile?.openingBalancePaise?.takeIf { it > 0L }
                ?.let { IndianFormatters.paiseToPlainRupeeString(it) } ?: "0"
        )
    }
    var monthlyBudgetText by remember(profile) {
        mutableStateOf(
            profile?.monthlyBudgetPaise?.takeIf { it > 0L }
                ?.let { IndianFormatters.paiseToPlainRupeeString(it) } ?: "0"
        )
    }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "सेटिंग्स और ऑफ़लाइन डेटा",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "बंद करें")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Offline Account Card
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AccountBalanceWallet,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = displayName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "बिना लॉगिन • पूर्णतः ऑफ़लाइन मोड सक्रिय",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "खाता और बजट सेटिंग्स",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = displayName,
                onValueChange = { if (it.length <= 100) displayName = it },
                label = { Text("आपका नाम / खाता नाम") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = openingBalanceText,
                onValueChange = {
                    openingBalanceText = it
                    errorMsg = null
                },
                label = { Text("शुरुआती बैलेंस (₹)") },
                prefix = { Text("₹ ") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = monthlyBudgetText,
                onValueChange = {
                    monthlyBudgetText = it
                    errorMsg = null
                },
                label = { Text("मासिक खर्च बजट लक्ष्य (₹, 0 = कोई सीमा नहीं)") },
                prefix = { Text("₹ ") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            if (errorMsg != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorMsg.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = financeColors.expense
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {
                    val openPaise = IndianFormatters.parseRupeesToPaise(
                        openingBalanceText.ifBlank { "0" }
                    )
                    val budgetPaise = IndianFormatters.parseRupeesToPaise(
                        monthlyBudgetText.ifBlank { "0" }
                    )
                    if (openPaise == null || budgetPaise == null) {
                        errorMsg = "कृपया सही संख्यात्मक राशि दर्ज करें।"
                        return@Button
                    }
                    onSaveSettings(
                        displayName.trim().ifBlank { "मेरा खाता" },
                        openPaise,
                        budgetPaise
                    )
                },
                enabled = !isSaving,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_settings_button")
            ) {
                Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isSaving) "सहेजा जा रहा है..." else "सेटिंग्स सहेजें")
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(14.dp))

            // Offline Local Storage Info
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.OfflinePin,
                            contentDescription = null,
                            tint = financeColors.income
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "100% ऑफ़लाइन व बिना Gmail लॉगिन",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = Icons.Rounded.Storage,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "आपके सभी ${transactions.size} लेन-देन और ${udharEntries.size} उधार रिकॉर्ड सीधे आपके फ़ोन के सुरक्षित SQLite (Room) डेटाबेस में सहेजे जाते हैं। ऐप बंद करने पर भी सारा हिसाब सुरक्षित रहता है।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = Icons.Rounded.LockOpen,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "कोई Gmail साइन-इन या इंटरनेट ज़रूरी नहीं है।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedButton(
                onClick = {
                    scope.launch {
                        val res = withContext(Dispatchers.IO) {
                            ReportExporter.exportJsonBackup(context, profile, transactions, udharEntries)
                        }
                        res.onSuccess { uri ->
                            ReportExporter.shareFile(
                                context = context,
                                uri = uri,
                                mimeType = "application/json",
                                title = "ऑफ़लाइन डेटा बैकअप साझा करें / सहेजें"
                            )
                        }.onFailure { err ->
                            onShowMessage("बैकअप बनाने में त्रुटि: ${err.localizedMessage ?: "अज्ञात त्रुटि"}")
                        }
                    }
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("export_backup_button")
            ) {
                Icon(Icons.Rounded.Backup, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("डेटा बैकअप (JSON) एक्सपोर्ट करें", fontWeight = FontWeight.SemiBold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    onDismiss()
                    onOpenApkDownload()
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("settings_apk_download_button")
            ) {
                Icon(Icons.Rounded.InstallMobile, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("ऐप APK डाउनलोड और इंस्टॉल गाइड", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
