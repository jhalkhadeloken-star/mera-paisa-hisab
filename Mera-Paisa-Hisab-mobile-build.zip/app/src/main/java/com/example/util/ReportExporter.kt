package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.example.BuildConfig
import com.example.data.model.LedgerTransaction
import com.example.data.model.MonthlyReportData
import com.example.data.model.PersonUdharSummary
import com.example.data.model.TransactionType
import com.example.data.model.UdharEntry
import com.example.data.model.UserProfile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class InstalledApkInfo(
    val versionName: String,
    val sizeBytes: Long,
    val isSplitBundle: Boolean,
    val isAvailable: Boolean,
    val suggestedFileName: String
)

object ReportExporter {

    private fun exportsDir(context: Context): File {
        return File(context.cacheDir, "exports").apply {
            if (!exists()) mkdirs()
        }
    }

    private fun toUri(context: Context, file: File): Uri {
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }

    fun exportMonthlyPdf(
        context: Context,
        report: MonthlyReportData,
        userName: String
    ): Result<Uri> {
        return try {
            val dir = exportsDir(context)
            val safeFileMonth = report.selectedMonthKey.replace("-", "_")
            val file = File(dir, "MeraPaisaHisab_Report_$safeFileMonth.pdf")

            val pdf = PdfDocument()
            val pageWidth = 595 // A4 width in PostScript points
            val pageHeight = 842
            val margin = 36f
            val contentWidth = (pageWidth - margin * 2).toInt()

            val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(13, 79, 68)
            }
            val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 20f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val subHeaderPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(213, 242, 234)
                textSize = 11f
            }
            val sectionPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(13, 79, 68)
                textSize = 14f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(24, 34, 31)
                textSize = 11f
            }
            val mutedPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(95, 112, 107)
                textSize = 10f
            }
            val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(215, 226, 222)
                strokeWidth = 1f
            }

            var pageNumber = 1
            var page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
            var canvas: Canvas = page.canvas

            // Top Banner
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), 96f, headerPaint)
            canvas.drawText("Mera Paisa Hisab — मासिक वित्तीय रिपोर्ट", margin, 38f, titlePaint)
            canvas.drawText(
                "माह: ${report.selectedMonthTitle}  |  उपयोगकर्ता: $userName  |  तारीख: ${IndianFormatters.formatNowTimestampIndian()}",
                margin,
                64f,
                subHeaderPaint
            )

            var y = 120f

            fun ensureSpace(needed: Float) {
                if (y + needed > pageHeight - 48f) {
                    pdf.finishPage(page)
                    pageNumber += 1
                    page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                    canvas = page.canvas
                    y = 42f
                }
            }

            // Summary Row Boxes
            val boxW = (contentWidth - 20f) / 3f
            drawMetricBox(
                canvas, margin, y, boxW, 60f,
                label = "कुल आय (Income)",
                value = IndianFormatters.formatInr(report.monthIncomePaise),
                bgColor = Color.rgb(220, 252, 231),
                fgColor = Color.rgb(21, 128, 61)
            )
            drawMetricBox(
                canvas, margin + boxW + 10f, y, boxW, 60f,
                label = "कुल खर्च (Expense)",
                value = IndianFormatters.formatInr(report.monthExpensePaise),
                bgColor = Color.rgb(254, 226, 226),
                fgColor = Color.rgb(220, 38, 38)
            )
            drawMetricBox(
                canvas, margin + (boxW + 10f) * 2f, y, boxW, 60f,
                label = "शुद्ध बचत (${report.savingsRatePercent}%)",
                value = IndianFormatters.formatInr(report.monthSavingsPaise),
                bgColor = Color.rgb(219, 234, 254),
                fgColor = Color.rgb(37, 99, 235)
            )
            y += 84f

            // Category Breakdown
            canvas.drawText("श्रेणीवार खर्च विवरण", margin, y, sectionPaint)
            y += 10f
            canvas.drawLine(margin, y, pageWidth - margin, y, linePaint)
            y += 18f

            if (report.categoryBreakdowns.isEmpty()) {
                canvas.drawText("इस महीने कोई खर्च दर्ज नहीं हुआ है।", margin, y, mutedPaint)
                y += 24f
            } else {
                for (cat in report.categoryBreakdowns) {
                    ensureSpace(22f)
                    canvas.drawText(cat.category, margin, y, bodyPaint)
                    val pctText = "${"%.1f".format(cat.percentage)}%"
                    canvas.drawText(pctText, margin + 220f, y, mutedPaint)
                    canvas.drawText(IndianFormatters.formatInr(cat.amountPaise), margin + 350f, y, bodyPaint)
                    y += 18f
                }
                y += 10f
            }

            // Previous Months Summary
            if (report.previousMonths.isNotEmpty()) {
                ensureSpace(60f)
                canvas.drawText("पिछले महीनों का सारांश", margin, y, sectionPaint)
                y += 10f
                canvas.drawLine(margin, y, pageWidth - margin, y, linePaint)
                y += 18f
                for (row in report.previousMonths.take(6)) {
                    ensureSpace(22f)
                    canvas.drawText(row.monthTitle, margin, y, bodyPaint)
                    canvas.drawText("आय: ${IndianFormatters.formatInr(row.incomePaise)}", margin + 150f, y, bodyPaint)
                    canvas.drawText("खर्च: ${IndianFormatters.formatInr(row.expensePaise)}", margin + 290f, y, bodyPaint)
                    canvas.drawText("बचत: ${IndianFormatters.formatInr(row.savingsPaise)}", margin + 425f, y, bodyPaint)
                    y += 18f
                }
                y += 10f
            }

            // Transaction Table
            ensureSpace(50f)
            canvas.drawText("लेन-देन सूची (DD-MM-YYYY)", margin, y, sectionPaint)
            y += 10f
            canvas.drawLine(margin, y, pageWidth - margin, y, linePaint)
            y += 16f

            if (report.monthTransactions.isEmpty()) {
                canvas.drawText("कोई लेन-देन उपलब्ध नहीं है।", margin, y, mutedPaint)
            } else {
                for (tx in report.monthTransactions) {
                    val dateStr = IndianFormatters.formatIndianDate(tx.dateKey)
                    val typeStr = tx.transactionType().hindiLabel
                    val amtStr = IndianFormatters.formatInr(tx.amountPaise)
                    val line = "$dateStr  |  $typeStr  |  ${tx.category}  |  $amtStr  —  ${tx.note}"
                    val layout = StaticLayout.Builder
                        .obtain(line, 0, line.length, bodyPaint, contentWidth)
                        .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                        .setLineSpacing(2f, 1f)
                        .build()
                    ensureSpace(layout.height + 10f)
                    canvas.save()
                    canvas.translate(margin, y)
                    layout.draw(canvas)
                    canvas.restore()
                    y += layout.height + 8f
                }
            }

            pdf.finishPage(page)
            FileOutputStream(file).use { out ->
                pdf.writeTo(out)
            }
            pdf.close()

            Result.success(toUri(context, file))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun drawMetricBox(
        canvas: Canvas,
        x: Float,
        y: Float,
        w: Float,
        h: Float,
        label: String,
        value: String,
        bgColor: Int,
        fgColor: Int
    ) {
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bgColor }
        canvas.drawRoundRect(x, y, x + w, y + h, 10f, 10f, bg)
        val lblPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = fgColor
            textSize = 10f
        }
        val valPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = fgColor
            textSize = 14f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText(label, x + 10f, y + 20f, lblPaint)
        canvas.drawText(value, x + 10f, y + 44f, valPaint)
    }

    /**
     * Generates a valid OOXML Excel (.xlsx) workbook with 3 worksheets:
     * 1) मासिक सारांश (Monthly Summary)
     * 2) लेन-देन विवरण (Transactions in DD-MM-YYYY)
     * 3) उधार खाता (Person-wise Udhar Balances)
     */
    fun exportMonthlyExcel(
        context: Context,
        report: MonthlyReportData,
        udharSummaries: List<PersonUdharSummary>
    ): Result<Uri> {
        return try {
            val dir = exportsDir(context)
            val safeFileMonth = report.selectedMonthKey.replace("-", "_")
            val file = File(dir, "MeraPaisaHisab_Excel_$safeFileMonth.xlsx")

            val summaryRows = mutableListOf<List<ExcelCell>>()
            summaryRows.add(listOf(ExcelCell.text("Mera Paisa Hisab — मासिक रिपोर्ट"), ExcelCell.text(report.selectedMonthTitle)))
            summaryRows.add(listOf(ExcelCell.text("कुल आय (₹)"), ExcelCell.number(report.monthIncomePaise / 100.0)))
            summaryRows.add(listOf(ExcelCell.text("कुल खर्च (₹)"), ExcelCell.number(report.monthExpensePaise / 100.0)))
            summaryRows.add(listOf(ExcelCell.text("शुद्ध बचत (₹)"), ExcelCell.number(report.monthSavingsPaise / 100.0)))
            summaryRows.add(listOf(ExcelCell.text("बचत दर (%)"), ExcelCell.number(report.savingsRatePercent.toDouble())))
            summaryRows.add(emptyList())
            summaryRows.add(listOf(ExcelCell.text("श्रेणी"), ExcelCell.text("खर्च (₹)"), ExcelCell.text("प्रतिशत (%)")))
            report.categoryBreakdowns.forEach {
                summaryRows.add(
                    listOf(
                        ExcelCell.text(it.category),
                        ExcelCell.number(it.amountPaise / 100.0),
                        ExcelCell.number(it.percentage.toDouble())
                    )
                )
            }
            if (report.previousMonths.isNotEmpty()) {
                summaryRows.add(emptyList())
                summaryRows.add(listOf(ExcelCell.text("माह"), ExcelCell.text("आय (₹)"), ExcelCell.text("खर्च (₹)"), ExcelCell.text("बचत (₹)")))
                report.previousMonths.forEach {
                    summaryRows.add(
                        listOf(
                            ExcelCell.text(it.monthTitle),
                            ExcelCell.number(it.incomePaise / 100.0),
                            ExcelCell.number(it.expensePaise / 100.0),
                            ExcelCell.number(it.savingsPaise / 100.0)
                        )
                    )
                }
            }

            val txRows = mutableListOf<List<ExcelCell>>()
            txRows.add(
                listOf(
                    ExcelCell.text("तारीख (DD-MM-YYYY)"),
                    ExcelCell.text("प्रकार"),
                    ExcelCell.text("श्रेणी"),
                    ExcelCell.text("राशि (₹)"),
                    ExcelCell.text("विवरण")
                )
            )
            report.monthTransactions.forEach { tx ->
                txRows.add(
                    listOf(
                        ExcelCell.text(IndianFormatters.formatIndianDate(tx.dateKey)),
                        ExcelCell.text(tx.transactionType().hindiLabel),
                        ExcelCell.text(tx.category),
                        ExcelCell.number(tx.amountPaise / 100.0),
                        ExcelCell.text(tx.note)
                    )
                )
            }

            val udharRows = mutableListOf<List<ExcelCell>>()
            udharRows.add(
                listOf(
                    ExcelCell.text("व्यक्ति का नाम"),
                    ExcelCell.text("फ़ोन"),
                    ExcelCell.text("उधार दिया (₹)"),
                    ExcelCell.text("उधार लिया (₹)"),
                    ExcelCell.text("शेष स्थिति"),
                    ExcelCell.text("शुद्ध राशि (₹)")
                )
            )
            udharSummaries.forEach { person ->
                val status = when {
                    person.netBalancePaise > 0 -> "लेना है"
                    person.netBalancePaise < 0 -> "देना है"
                    else -> "हिसाब बराबर"
                }
                udharRows.add(
                    listOf(
                        ExcelCell.text(person.personName),
                        ExcelCell.text(person.phone.orEmpty()),
                        ExcelCell.number(person.totalGivenPaise / 100.0),
                        ExcelCell.number(person.totalBorrowedPaise / 100.0),
                        ExcelCell.text(status),
                        ExcelCell.number(kotlin.math.abs(person.netBalancePaise) / 100.0)
                    )
                )
            }

            ZipOutputStream(FileOutputStream(file)).use { zip ->
                writeZipEntry(zip, "[Content_Types].xml", contentTypesXml())
                writeZipEntry(zip, "_rels/.rels", rootRelsXml())
                writeZipEntry(zip, "xl/workbook.xml", workbookXml())
                writeZipEntry(zip, "xl/_rels/workbook.xml.rels", workbookRelsXml())
                writeZipEntry(zip, "xl/styles.xml", stylesXml())
                writeZipEntry(zip, "xl/worksheets/sheet1.xml", buildSheetXml(summaryRows))
                writeZipEntry(zip, "xl/worksheets/sheet2.xml", buildSheetXml(txRows))
                writeZipEntry(zip, "xl/worksheets/sheet3.xml", buildSheetXml(udharRows))
            }

            Result.success(toUri(context, file))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun exportJsonBackup(
        context: Context,
        profile: UserProfile?,
        transactions: List<LedgerTransaction>,
        udharEntries: List<UdharEntry>
    ): Result<Uri> {
        return try {
            val dir = exportsDir(context)
            val file = File(dir, "MeraPaisaHisab_Backup.json")

            val root = JSONObject().apply {
                put("app", "Mera Paisa Hisab")
                put("exportedAtMillis", System.currentTimeMillis())
                put("exportedDate", IndianFormatters.formatIndianDate(IndianFormatters.todayDateKey()))
                put(
                    "profile",
                    JSONObject().apply {
                        put("displayName", profile?.displayName ?: "मेरा खाता")
                        put("openingBalancePaise", profile?.openingBalancePaise ?: 0L)
                        put("monthlyBudgetPaise", profile?.monthlyBudgetPaise ?: 0L)
                        put("currency", "INR")
                    }
                )
                put(
                    "transactions",
                    JSONArray().apply {
                        transactions.forEach { tx ->
                            put(
                                JSONObject().apply {
                                    put("id", tx.id)
                                    put("type", tx.type)
                                    put("amountPaise", tx.amountPaise)
                                    put("category", tx.category)
                                    put("note", tx.note)
                                    put("dateKey", tx.dateKey)
                                    put("monthKey", tx.monthKey)
                                    put("source", tx.source)
                                    put("createdAtMillis", tx.createdAtMillis)
                                    put("updatedAtMillis", tx.updatedAtMillis)
                                }
                            )
                        }
                    }
                )
                put(
                    "udharEntries",
                    JSONArray().apply {
                        udharEntries.forEach { entry ->
                            put(
                                JSONObject().apply {
                                    put("id", entry.id)
                                    put("personName", entry.personName)
                                    put("phone", entry.phone ?: "")
                                    put("entryType", entry.entryType)
                                    put("amountPaise", entry.amountPaise)
                                    put("dateKey", entry.dateKey)
                                    put("dueDateKey", entry.dueDateKey ?: "")
                                    put("note", entry.note)
                                    put("createdAtMillis", entry.createdAtMillis)
                                    put("updatedAtMillis", entry.updatedAtMillis)
                                }
                            )
                        }
                    }
                )
            }

            file.writeText(root.toString(2), Charsets.UTF_8)
            Result.success(toUri(context, file))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun getInstalledApkInfo(context: Context): InstalledApkInfo {
        val appInfo = context.applicationInfo
        val isSplit = !appInfo.splitPublicSourceDirs.isNullOrEmpty()
        val apkPath = appInfo.publicSourceDir ?: appInfo.sourceDir
        val apkFile = apkPath?.let { File(it) }
        val available = !isSplit && apkFile != null && apkFile.exists() && apkFile.canRead() && apkFile.length() > 0L
        val versionName = BuildConfig.VERSION_NAME.ifBlank { "1.0" }
        return InstalledApkInfo(
            versionName = versionName,
            sizeBytes = if (available) apkFile!!.length() else 0L,
            isSplitBundle = isSplit,
            isAvailable = available,
            suggestedFileName = "MeraPaisaHisab-v$versionName.apk"
        )
    }

    fun copyInstalledApkToUri(context: Context, destinationUri: Uri): Result<Long> {
        return try {
            val info = getInstalledApkInfo(context)
            check(!info.isSplitBundle) {
                "यह इंस्टॉलेशन Split App Bundle के रूप में है, इसलिए सिंगल APK एक्सपोर्ट उपलब्ध नहीं है।"
            }
            val apkPath = context.applicationInfo.publicSourceDir ?: context.applicationInfo.sourceDir
            val sourceFile = apkPath?.let { File(it) }
            check(sourceFile != null && sourceFile.exists() && sourceFile.canRead()) {
                "इंस्टॉल की गई APK फ़ाइल उपलब्ध नहीं है।"
            }

            var copiedBytes = 0L
            context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                FileInputStream(sourceFile).use { input ->
                    copiedBytes = input.copyTo(out)
                }
                out.flush()
            } ?: error("फ़ाइल सेव करने के लिए स्टोरेज स्ट्रीम नहीं खुल सकी।")

            Result.success(copiedBytes)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun exportInstalledApkForShare(context: Context): Result<Uri> {
        return try {
            val info = getInstalledApkInfo(context)
            check(info.isAvailable) {
                if (info.isSplitBundle) {
                    "यह ऐप Split App Bundle के रूप में इंस्टॉल है। पूरा APK AI Studio Settings मेन्यू से डाउनलोड करें।"
                } else {
                    "इंस्टॉल की गई APK फ़ाइल उपलब्ध नहीं है।"
                }
            }
            val apkPath = context.applicationInfo.publicSourceDir ?: context.applicationInfo.sourceDir
            val sourceFile = File(checkNotNull(apkPath))
            val dir = exportsDir(context)
            val destFile = File(dir, info.suggestedFileName)
            FileInputStream(sourceFile).use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                    output.flush()
                }
            }
            Result.success(toUri(context, destFile))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun shareFile(context: Context, uri: Uri, mimeType: String, title: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, title))
    }

    private sealed class ExcelCell {
        data class Text(val value: String) : ExcelCell()
        data class Number(val value: Double) : ExcelCell()

        companion object {
            fun text(v: String) = Text(v)
            fun number(v: Double) = Number(v)
        }
    }

    private fun writeZipEntry(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun escapeXml(raw: String): String {
        val sb = StringBuilder(raw.length)
        for (ch in raw) {
            when (ch) {
                '&' -> sb.append("&amp;")
                '<' -> sb.append("&lt;")
                '>' -> sb.append("&gt;")
                '"' -> sb.append("&quot;")
                '\'' -> sb.append("&apos;")
                else -> if (ch.code >= 0x20 || ch == '\t' || ch == '\n' || ch == '\r') sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun colRef(colIndex: Int): String {
        var idx = colIndex
        val sb = StringBuilder()
        while (idx >= 0) {
            sb.insert(0, ('A' + (idx % 26)))
            idx = idx / 26 - 1
        }
        return sb.toString()
    }

    private fun buildSheetXml(rows: List<List<ExcelCell>>): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""")
        rows.forEachIndexed { rIdx, row ->
            val rowNum = rIdx + 1
            sb.append("""<row r="$rowNum">""")
            row.forEachIndexed { cIdx, cell ->
                val ref = "${colRef(cIdx)}$rowNum"
                when (cell) {
                    is ExcelCell.Text -> {
                        sb.append("""<c r="$ref" t="inlineStr"><is><t>${escapeXml(cell.value)}</t></is></c>""")
                    }
                    is ExcelCell.Number -> {
                        sb.append("""<c r="$ref"><v>${cell.value}</v></c>""")
                    }
                }
            }
            sb.append("</row>")
        }
        sb.append("</sheetData></worksheet>")
        return sb.toString()
    }

    private fun contentTypesXml() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/worksheets/sheet3.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>"""

    private fun rootRelsXml() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

    private fun workbookXml() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="मासिक सारांश" sheetId="1" r:id="rId1"/>
    <sheet name="लेन-देन विवरण" sheetId="2" r:id="rId2"/>
    <sheet name="उधार खाता" sheetId="3" r:id="rId3"/>
  </sheets>
</workbook>"""

    private fun workbookRelsXml() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/>
  <Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

    private fun stylesXml() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>
  <fills count="1"><fill><patternFill patternType="none"/></fill></fills>
  <borders count="1"><border/></borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs>
</styleSheet>"""
}
