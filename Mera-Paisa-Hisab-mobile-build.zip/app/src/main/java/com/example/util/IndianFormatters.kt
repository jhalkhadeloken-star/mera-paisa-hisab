package com.example.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import java.math.BigDecimal
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs

object IndianFormatters {

    private val hindiMonthNames = arrayOf(
        "जनवरी", "फ़रवरी", "मार्च", "अप्रैल", "मई", "जून",
        "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर"
    )

    private val hindiShortMonths = arrayOf(
        "जन", "फ़र", "मार्च", "अप्रै", "मई", "जून",
        "जुल", "अग", "सित", "अक्टू", "नव", "दिस"
    )

    fun formatInr(paise: Long, showPlus: Boolean = false, showSignIfNegative: Boolean = true): String {
        val isNegative = paise < 0
        val absPaise = abs(paise)
        val rupees = absPaise / 100L
        val remPaise = (absPaise % 100L).toInt()

        val formattedRupees = formatIndianGrouping(rupees)
        val decimalPart = if (remPaise > 0) {
            ".${remPaise.toString().padStart(2, '0')}"
        } else {
            ""
        }

        val prefix = when {
            isNegative && showSignIfNegative -> "-₹"
            !isNegative && showPlus && paise > 0 -> "+₹"
            else -> "₹"
        }
        return "$prefix$formattedRupees$decimalPart"
    }

    private fun formatIndianGrouping(value: Long): String {
        val str = value.toString()
        if (str.length <= 3) return str
        val lastThree = str.takeLast(3)
        val remaining = str.dropLast(3)
        val sb = StringBuilder()
        var idx = remaining.length
        while (idx > 0) {
            val start = maxOf(0, idx - 2)
            if (sb.isNotEmpty()) sb.insert(0, ",")
            sb.insert(0, remaining.substring(start, idx))
            idx = start
        }
        return "$sb,$lastThree"
    }

    fun formatCompactInr(paise: Long): String {
        val rupees = abs(paise) / 100.0
        val sign = if (paise < 0) "-" else ""
        val symbols = DecimalFormatSymbols(Locale.US)
        val df = DecimalFormat("0.#", symbols)
        return when {
            rupees >= 10000000.0 -> "${sign}₹${df.format(rupees / 10000000.0)} Cr"
            rupees >= 100000.0 -> "${sign}₹${df.format(rupees / 100000.0)} L"
            rupees >= 1000.0 -> "${sign}₹${df.format(rupees / 1000.0)}K"
            else -> formatInr(paise)
        }
    }

    fun paiseToPlainRupeeString(paise: Long): String {
        if (paise == 0L) return ""
        val whole = paise / 100L
        val rem = paise % 100L
        return if (rem == 0L) {
            whole.toString()
        } else {
            "$whole.${rem.toString().padStart(2, '0')}"
        }
    }

    fun parseRupeesToPaise(raw: String): Long? {
        val cleaned = raw.trim().replace(",", "").replace("₹", "")
        if (cleaned.isEmpty()) return null
        return try {
            val bd = BigDecimal(cleaned)
            if (bd < BigDecimal.ZERO) return null
            val paiseBd = bd.multiply(BigDecimal(100))
            val paise = paiseBd.toLong()
            if (paise > 100_000_000_000L) null else paise
        } catch (_: Exception) {
            null
        }
    }

    fun todayDateKey(): String {
        val cal = Calendar.getInstance()
        return calendarToDateKey(cal)
    }

    fun yesterdayDateKey(): String {
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        return calendarToDateKey(cal)
    }

    fun daysAgoDateKey(daysAgo: Int): String {
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -daysAgo) }
        return calendarToDateKey(cal)
    }

    fun currentMonthKey(): String = todayDateKey().substring(0, 7)

    fun dateKeyToMonthKey(dateKey: String): String {
        return if (dateKey.length >= 7) dateKey.substring(0, 7) else currentMonthKey()
    }

    fun calendarToDateKey(cal: Calendar): String {
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH) + 1
        val d = cal.get(Calendar.DAY_OF_MONTH)
        return "%04d-%02d-%02d".format(Locale.US, y, m, d)
    }

    fun millisToDateKey(millis: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        return calendarToDateKey(cal)
    }

    fun dateKeyToMillis(dateKey: String): Long? {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            sdf.parse(dateKey)?.time
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Converts canonical YYYY-MM-DD into Indian format DD-MM-YYYY.
     */
    fun formatIndianDate(dateKey: String): String {
        val parts = dateKey.split("-")
        if (parts.size != 3) return dateKey
        return "${parts[2]}-${parts[1]}-${parts[0]}"
    }

    fun formatIndianDateLabel(dateKey: String): String {
        val today = todayDateKey()
        val yesterday = yesterdayDateKey()
        return when (dateKey) {
            today -> "आज (${formatIndianDate(dateKey)})"
            yesterday -> "कल (${formatIndianDate(dateKey)})"
            else -> formatIndianDate(dateKey)
        }
    }

    fun formatShortDayLabel(dateKey: String): String {
        val parts = dateKey.split("-")
        if (parts.size != 3) return dateKey
        val day = parts[2].toIntOrNull() ?: return dateKey
        val monthIdx = (parts[1].toIntOrNull() ?: 1) - 1
        val monthShort = hindiShortMonths.getOrElse(monthIdx) { parts[1] }
        return "$day $monthShort"
    }

    fun formatIndianMonthTitle(monthKey: String): String {
        val parts = monthKey.split("-")
        if (parts.size != 2) return monthKey
        val year = parts[0]
        val monthIdx = (parts[1].toIntOrNull() ?: 1) - 1
        val monthName = hindiMonthNames.getOrElse(monthIdx) { parts[1] }
        return "$monthName $year"
    }

    fun formatNowTimestampIndian(): String {
        val sdf = SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale.US)
        return sdf.format(Date())
    }

    fun isNetworkAvailable(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun observeNetworkConnectivity(context: Context): Flow<Boolean> = callbackFlow {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        if (cm == null) {
            trySend(false)
            awaitClose { }
            return@callbackFlow
        }

        trySend(isNetworkAvailable(context))

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                trySend(true)
            }

            override fun onLost(network: Network) {
                trySend(isNetworkAvailable(context))
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                trySend(networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET))
            }
        }

        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        try {
            cm.registerNetworkCallback(request, callback)
        } catch (_: Exception) {
            trySend(isNetworkAvailable(context))
        }

        awaitClose {
            try {
                cm.unregisterNetworkCallback(callback)
            } catch (_: Exception) {
            }
        }
    }.distinctUntilChanged()
}
